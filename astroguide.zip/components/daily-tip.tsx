"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { XIcon } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

const tips = [
  "Mercury retrograde is ending soon. Expect communication to improve in the coming days.",
  "The new moon is a perfect time to set intentions and start new projects.",
  "Take a moment today to meditate and connect with your inner self.",
  "Venus is in your favor today. Express love and appreciation to those around you.",
  "Your ruling planet is entering a new phase. Pay attention to subtle changes in your mood.",
  "Today's planetary alignment favors creative endeavors. Let your imagination flow.",
  "The stars suggest taking time for self-care today. Your energy needs replenishing.",
  "Jupiter's influence brings opportunities for growth. Stay open to new possibilities.",
  "The cosmos encourages you to step out of your comfort zone today.",
  "Planetary positions suggest it's a good day for financial planning and decisions.",
]

const DailyTip = () => {
  const [showTip, setShowTip] = useState(false)
  const [tip, setTip] = useState("")

  useEffect(() => {
    // Check if we've shown a tip today
    const lastTipDate = localStorage.getItem("lastTipDate")
    const today = new Date().toDateString()

    if (lastTipDate !== today) {
      // Get a random tip
      const randomTip = tips[Math.floor(Math.random() * tips.length)]
      setTip(randomTip)

      // Show tip after a short delay
      const timer = setTimeout(() => {
        setShowTip(true)
        localStorage.setItem("lastTipDate", today)
      }, 2000)

      return () => clearTimeout(timer)
    }
  }, [])

  const closeTip = () => {
    setShowTip(false)
  }

  return (
    <AnimatePresence>
      {showTip && (
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 50 }}
          className="fixed bottom-4 right-4 z-50 max-w-md"
        >
          <Card className="border-primary">
            <CardContent className="p-4">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-semibold text-lg">✨ Daily Astrology Tip</h3>
                <Button variant="ghost" size="icon" className="h-6 w-6" onClick={closeTip}>
                  <XIcon className="h-4 w-4" />
                </Button>
              </div>
              <p className="text-muted-foreground">{tip}</p>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

export default DailyTip

