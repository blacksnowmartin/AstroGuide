"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { MoonIcon, SunIcon, HeartIcon, CalculatorIcon } from "lucide-react"
import { motion } from "framer-motion"
import DailyTip from "@/components/daily-tip"

const Hero = () => {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <div className="relative">
      <div className="absolute inset-0 star-bg opacity-30 z-0"></div>

      <section className="relative z-10 py-20 px-4">
        <div className="container mx-auto text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-primary via-accent to-secondary">
              Discover Your Cosmic Path
            </h1>
            <p className="text-xl md:text-2xl text-foreground/80 max-w-3xl mx-auto mb-10">
              Explore daily horoscopes, zodiac compatibility, and numerology insights tailored just for you.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.5 }}
            className="flex flex-wrap justify-center gap-4 mb-16"
          >
            <Button size="lg" asChild>
              <Link href="/horoscope">Get Your Daily Horoscope</Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/zodiac">Explore Zodiac Signs</Link>
            </Button>
          </motion.div>

          <DailyTip />

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.5 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-16"
          >
            <FeatureCard
              icon={<SunIcon className="h-10 w-10 text-yellow-500" />}
              title="Daily Horoscope"
              description="Get personalized daily insights based on your zodiac sign."
              href="/horoscope"
            />
            <FeatureCard
              icon={<MoonIcon className="h-10 w-10 text-blue-400" />}
              title="Zodiac Signs"
              description="Explore detailed profiles of all twelve zodiac signs."
              href="/zodiac"
            />
            <FeatureCard
              icon={<HeartIcon className="h-10 w-10 text-red-400" />}
              title="Compatibility"
              description="Check your romantic and friendship compatibility."
              href="/compatibility"
            />
            <FeatureCard
              icon={<CalculatorIcon className="h-10 w-10 text-green-400" />}
              title="Numerology"
              description="Discover your life path number and its meaning."
              href="/numerology"
            />
          </motion.div>
        </div>
      </section>
    </div>
  )
}

const FeatureCard = ({
  icon,
  title,
  description,
  href,
}: {
  icon: React.ReactNode
  title: string
  description: string
  href: string
}) => {
  return (
    <Link href={href}>
      <Card className="p-6 h-full flex flex-col items-center text-center transition-all duration-300 hover:border-primary zodiac-card">
        <div className="mb-4 p-3 rounded-full bg-muted flex items-center justify-center">{icon}</div>
        <h3 className="text-xl font-semibold mb-2">{title}</h3>
        <p className="text-muted-foreground">{description}</p>
      </Card>
    </Link>
  )
}

export default Hero

