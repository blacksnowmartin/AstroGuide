export const lifePathData = [
  {
    number: 1,
    title: "The Leader",
    description:
      "Life Path Number 1 represents independence, originality, and natural leadership. You're a pioneer with strong determination and ambition. Your life's journey is about developing confidence, individuality, and the courage to forge your own path.",
    lifePurpose:
      "Your purpose is to develop leadership skills, independence, and innovative thinking. You're here to initiate new ideas and inspire others through your courage and originality.",
    positiveTraits: [
      "Independent and self-reliant",
      "Ambitious and determined",
      "Creative and innovative",
      "Natural leader",
      "Pioneering spirit",
    ],
    challenges: [
      "Can be domineering or egotistical",
      "May struggle with stubbornness",
      "Sometimes impatient with others",
      "May have difficulty accepting help",
      "Can be overly competitive",
    ],
    careerPaths:
      "You excel in careers that allow you to lead, innovate, or work independently. Great options include entrepreneur, executive, inventor, explorer, artist, or any pioneering role that hasn't been done before.",
  },
  {
    number: 2,
    title: "The Mediator",
    description:
      "Life Path Number 2 represents cooperation, diplomacy, and sensitivity. You're naturally intuitive with a gift for creating harmony in relationships. Your life's journey is about developing patience, partnership skills, and finding balance between giving to others and self-care.",
    lifePurpose:
      "Your purpose is to bring peace, cooperation, and balance to situations. You're here to teach the importance of relationships, diplomacy, and emotional intelligence in a world that often values individual achievement over collaboration.",
    positiveTraits: [
      "Cooperative and diplomatic",
      "Sensitive and intuitive",
      "Patient and detail-oriented",
      "Excellent mediator",
      "Supportive and caring",
    ],
    challenges: [
      "Can be overly sensitive",
      "May avoid conflict at all costs",
      "Sometimes indecisive",
      "Can be too dependent on others",
      "May neglect own needs for others",
    ],
    careerPaths:
      "You thrive in careers involving partnership, support roles, and diplomacy. Consider counselor, mediator, teacher, team member, diplomat, social worker, or any role requiring emotional intelligence and cooperation.",
  },
  {
    number: 3,
    title: "The Expressive Creator",
    description:
      "Life Path Number 3 represents creativity, self-expression, and joy. You have natural artistic talents and a gift for communication. Your life's journey is about developing your creative voice, inspiring others, and learning to channel your emotions into positive expression.",
    lifePurpose:
      "Your purpose is to bring beauty, creativity, and joy into the world. You're here to inspire others through your self-expression and to remind everyone of the importance of play, creativity, and authentic communication.",
    positiveTraits: [
      "Highly creative and artistic",
      "Excellent communicator",
      "Charming and sociable",
      "Optimistic and joyful",
      "Inspiring to others",
    ],
    challenges: [
      "Can scatter energy across too many projects",
      "May struggle with follow-through",
      "Sometimes overly critical",
      "Can be moody or emotionally reactive",
      "May use humor to avoid serious issues",
    ],
    careerPaths:
      "You excel in creative and communicative fields. Consider writer, artist, performer, designer, teacher, counselor, or any career that allows you to express yourself and inspire others.",
  },
  {
    number: 4,
    title: "The Builder",
    description:
      "Life Path Number 4 represents stability, practicality, and building solid foundations. You're hardworking, reliable, and methodical in your approach to life. Your journey is about creating security through disciplined effort and learning the value of patience and persistence.",
    lifePurpose:
      "Your purpose is to build structures, systems, and foundations that others can rely on. You're here to teach the importance of integrity, hard work, and practical solutions in creating lasting success and security.",
    positiveTraits: [
      "Hardworking and dedicated",
      "Practical and reliable",
      "Excellent organizational skills",
      "Strong sense of honesty and integrity",
      "Patient and persistent",
    ],
    challenges: [
      "Can be too rigid or stubborn",
      "May resist necessary changes",
      "Sometimes workaholic tendencies",
      "Can be overly cautious",
      "May judge others by their own high standards",
    ],
    careerPaths:
      "You thrive in careers requiring organization, reliability, and attention to detail. Consider manager, accountant, engineer, builder, analyst, researcher, or any role involving creating systems and maintaining order.",
  },
  {
    number: 5,
    title: "The Freedom Seeker",
    description:
      "Life Path Number 5 represents freedom, adventure, and versatility. You're adaptable, progressive, and crave variety and new experiences. Your life's journey is about embracing change, exploring diverse paths, and learning to use your freedom responsibly.",
    lifePurpose:
      "Your purpose is to experience life fully and inspire others to embrace change and adventure. You're here to teach flexibility, adaptability, and the constructive use of freedom in a world that often seeks security through limitation.",
    positiveTraits: [
      "Adaptable and versatile",
      "Adventurous and progressive",
      "Excellent communicator",
      "Quick-thinking and resourceful",
      "Charismatic and persuasive",
    ],
    challenges: [
      "Can be restless or impatient",
      "May avoid commitments",
      "Sometimes scattered energy",
      "Can be overindulgent",
      "May struggle with self-discipline",
    ],
    careerPaths:
      "You excel in careers offering variety, travel, or frequent change. Consider travel agent, marketing, sales, entrepreneur, journalist, tour guide, or any role involving communication and new experiences.",
  },
  {
    number: 6,
    title: "The Nurturer",
    description:
      "Life Path Number 6 represents responsibility, care, and harmony. You have a natural ability to nurture others and create beauty. Your life's journey is about finding balance between caring for others and self-care, while creating harmony in your environment.",
    lifePurpose:
      "Your purpose is to bring healing, beauty, and balance to your community and family. You're here to teach the importance of responsibility, nurturing, and creating harmony through service and compassionate understanding.",
    positiveTraits: [
      "Nurturing and compassionate",
      "Responsible and reliable",
      "Creative with aesthetic sense",
      "Harmonious and peace-loving",
      "Protective of loved ones",
    ],
    challenges: [
      "Can be self-sacrificing",
      "May be perfectionistic",
      "Sometimes interfering or controlling",
      "Can be anxious about responsibilities",
      "May struggle with martyrdom",
    ],
    careerPaths:
      "You thrive in careers involving care, service, and creating harmony. Consider counselor, teacher, healthcare provider, interior designer, community organizer, or any role helping others and creating beautiful environments.",
  },
  {
    number: 7,
    title: "The Seeker",
    description:
      "Life Path Number 7 represents analysis, wisdom, and spiritual awareness. You have a naturally analytical mind and seek deeper understanding. Your life's journey is about developing wisdom through both intellectual and spiritual exploration.",
    lifePurpose:
      "Your purpose is to seek truth and develop wisdom that benefits humanity. You're here to teach the importance of reflection, analysis, and spiritual awareness in a world often focused on material success and external validation.",
    positiveTraits: [
      "Analytical and thoughtful",
      "Spiritually aware",
      "Excellent researcher",
      "Independent thinker",
      "Introspective and wise",
    ],
    challenges: [
      "Can be overly critical or perfectionistic",
      "May isolate socially",
      "Sometimes skeptical to a fault",
      "Can overthink decisions",
      "May struggle with practical matters",
    ],
    careerPaths:
      "You excel in careers involving research, analysis, and specialized knowledge. Consider researcher, scientist, analyst, philosopher, spiritual teacher, writer, or any role requiring deep thinking and specialized expertise.",
  },
  {
    number: 8,
    title: "The Achiever",
    description:
      "Life Path Number 8 represents ambition, authority, and material success. You have natural leadership abilities and a talent for creating abundance. Your life's journey is about developing personal power, financial wisdom, and learning to balance material and spiritual values.",
    lifePurpose:
      "Your purpose is to achieve success and use your power and resources to benefit others. You're here to teach the importance of ethical leadership, practical manifestation, and the responsible use of power and wealth.",
    positiveTraits: [
      "Ambitious and goal-oriented",
      "Natural authority and leadership",
      "Practical and realistic",
      "Excellent with finances and resources",
      "Determined and resilient",
    ],
    challenges: [
      "Can be workaholic or status-focused",
      "May be controlling or domineering",
      "Sometimes judgmental of 'less successful' people",
      "Can struggle with work-life balance",
      "May focus too much on material success",
    ],
    careerPaths:
      "You thrive in careers involving leadership, finance, and achievement. Consider executive, entrepreneur, financial advisor, manager, real estate developer, or any role involving building wealth and exercising authority.",
  },
  {
    number: 9,
    title: "The Humanitarian",
    description:
      "Life Path Number 9 represents compassion, wisdom, and completion. You have a natural ability to see the bigger picture and feel deeply for humanity. Your life's journey is about developing universal love, letting go of attachments, and serving the greater good.",
    lifePurpose:
      "Your purpose is to serve humanity with compassion and wisdom. You're here to teach the importance of forgiveness, letting go, and recognizing our shared humanity across all apparent differences.",
    positiveTraits: [
      "Compassionate and humanitarian",
      "Wise and broad-minded",
      "Creative and artistic",
      "Generous and giving",
      "Idealistic and inspiring",
    ],
    challenges: [
      "Can be emotionally distant",
      "May struggle with letting go",
      "Sometimes impractical idealism",
      "Can feel misunderstood",
      "May take on others' problems",
    ],
    careerPaths:
      "You excel in careers involving service to humanity and creative expression. Consider humanitarian work, counseling, healing arts, teaching, artistic pursuits, or any role serving the greater good and inspiring others.",
  },
  {
    number: 11,
    title: "The Intuitive Messenger",
    description:
      "Life Path Number 11 is a Master Number representing intuition, inspiration, and spiritual insight. You have heightened sensitivity and visionary abilities. Your life's journey is about developing your intuitive gifts and learning to channel your spiritual awareness into practical service.",
    lifePurpose:
      "Your purpose is to elevate consciousness and inspire others through your intuitive insights. You're here to bridge the spiritual and material worlds, bringing higher awareness into everyday life through your sensitivity and vision.",
    positiveTraits: [
      "Highly intuitive and psychic",
      "Inspirational to others",
      "Idealistic and visionary",
      "Sensitive and empathetic",
      "Spiritually aware",
    ],
    challenges: [
      "Can be overly sensitive",
      "May struggle with nervous tension",
      "Sometimes impractical or unrealistic",
      "Can feel misunderstood",
      "May have difficulty grounding energy",
    ],
    careerPaths:
      "You thrive in careers involving inspiration, healing, and spiritual awareness. Consider spiritual teacher, counselor, artist, musician, writer, healer, or any role using your intuitive gifts to inspire and elevate others.",
  },
  {
    number: 22,
    title: "The Master Builder",
    description:
      "Life Path Number 22 is a Master Number representing practical vision and the ability to manifest on a large scale. You have the potential to transform innovative ideas into concrete reality. Your life's journey is about developing the discipline to bring your grand visions into material form.",
    lifePurpose:
      "Your purpose is to build structures, systems, or organizations that benefit humanity on a large scale. You're here to demonstrate how spiritual ideals can be manifested in practical ways that transform society and create lasting change.",
    positiveTraits: [
      "Visionary with practical abilities",
      "Powerful manifestation capacity",
      "Leadership on a large scale",
      "Disciplined and organized",
      "Humanitarian ideals",
    ],
    challenges: [
      "Can feel burdened by potential",
      "May struggle with enormous expectations",
      "Sometimes overly focused on work",
      "Can be controlling of projects",
      "May avoid personal emotional issues",
    ],
    careerPaths:
      "You excel in careers allowing you to create large-scale projects with humanitarian benefits. Consider architect, urban planner, business leader, politician, organizational founder, or any role involving building structures that serve many people.",
  },
  {
    number: 33,
    title: "The Master Teacher",
    description:
      "Life Path Number 33 is a Master Number representing compassionate service, spiritual teaching, and healing. You have extraordinary empathy and a capacity to uplift others. Your life's journey is about channeling your nurturing energy into teaching and healing that transforms lives.",
    lifePurpose:
      "Your purpose is to elevate humanity through compassionate teaching, healing, and creative expression. You're here to demonstrate selfless service and unconditional love, helping others recognize their own divine nature and potential.",
    positiveTraits: [
      "Deeply compassionate and loving",
      "Natural healer and teacher",
      "Highly creative and expressive",
      "Nurturing and supportive",
      "Spiritually enlightened",
    ],
    challenges: [
      "Can be self-sacrificing",
      "May neglect personal needs",
      "Sometimes overwhelmed by others' pain",
      "Can struggle with setting boundaries",
      "May have difficulty receiving help",
    ],
    careerPaths:
      "You thrive in careers involving teaching, healing, and uplifting others. Consider spiritual teacher, healer, counselor, artist with a message, nonprofit leader, or any role where you can nurture others' growth and healing on a profound level.",
  },
]

