export const zodiacSigns = [
  {
    id: "aries",
    name: "Aries",
    symbol: "♈",
    symbolName: "The Ram",
    dates: "March 21 - April 19",
    element: "Fire",
    quality: "Cardinal",
    rulingPlanet: "Mars",
    traits: ["Courageous", "Determined", "Confident", "Enthusiastic", "Passionate"],
    strengths:
      "Aries are natural leaders with boundless energy and enthusiasm. They're courageous, determined, and confident in pursuing their goals.",
    weaknesses:
      "Can be impatient, short-tempered, and impulsive. May act before thinking and struggle with finishing what they start.",
    luckyNumbers: [1, 8, 17],
    luckyColors: ["Red", "Orange", "Yellow"],
    luckyNumber: 9,
    luckyColor: "Red",
    mood: "Energetic",
    compatibility: "Libra",
    dailyHoroscope:
      "Today brings a surge of energy that propels you toward your goals. Your natural leadership abilities are heightened, making this an excellent day to take charge of projects or inspire others. Be mindful of impatience; not everyone moves at your pace. A surprising conversation could open new doors.",
    loveHoroscope:
      "Your passionate nature is especially magnetic today. If you're in a relationship, your partner appreciates your directness and enthusiasm. Single Aries might find themselves attracted to someone who challenges them intellectually.",
    careerHoroscope:
      "Your competitive spirit serves you well in the workplace today. You're likely to impress superiors with your initiative and bold ideas. Consider taking the lead on a new project that showcases your strengths.",
    healthHoroscope:
      "Channel your abundant energy into physical activity to maintain balance. A high-intensity workout would be particularly satisfying today. Pay attention to your head and face area, which are ruled by Aries.",
  },
  {
    id: "taurus",
    name: "Taurus",
    symbol: "♉",
    symbolName: "The Bull",
    dates: "April 20 - May 20",
    element: "Earth",
    quality: "Fixed",
    rulingPlanet: "Venus",
    traits: ["Reliable", "Patient", "Practical", "Devoted", "Responsible"],
    strengths:
      "Taurus individuals are reliable, patient, and practical. They have a strong sense of determination and work steadily toward their goals.",
    weaknesses:
      "Can be stubborn, possessive, and uncompromising. May resist change and become too fixed in their ways.",
    luckyNumbers: [2, 6, 9],
    luckyColors: ["Green", "Pink", "Blue"],
    luckyNumber: 6,
    luckyColor: "Green",
    mood: "Grounded",
    compatibility: "Scorpio",
    dailyHoroscope:
      "Your practical nature serves you well today as you navigate financial matters with ease. Stability is highlighted, making this a good time to assess your resources and make long-term plans. Your patience allows you to wait for the right moment before making important decisions. Indulge in something that brings sensory pleasure.",
    loveHoroscope:
      "Your loyal and dependable nature strengthens your relationships today. Partners appreciate your steadfastness. Single Taurus individuals might find connection through shared values and interests rather than fleeting attraction.",
    careerHoroscope:
      "Your methodical approach to work impresses colleagues today. You excel at tasks requiring attention to detail and persistence. Consider ways to increase your financial security through your career path.",
    healthHoroscope:
      "Focus on throat care today, as this area is ruled by Taurus. Gentle neck stretches and staying hydrated will help. Your connection to the earth element suggests grounding activities like gardening or walking barefoot in grass would be beneficial.",
  },
  {
    id: "gemini",
    name: "Gemini",
    symbol: "♊",
    symbolName: "The Twins",
    dates: "May 21 - June 20",
    element: "Air",
    quality: "Mutable",
    rulingPlanet: "Mercury",
    traits: ["Gentle", "Affectionate", "Curious", "Adaptable", "Quick-witted"],
    strengths:
      "Geminis are adaptable, outgoing, and intellectually curious. They're excellent communicators with a quick wit and youthful enthusiasm.",
    weaknesses:
      "Can be nervous, inconsistent, and indecisive. May try to do too many things at once and struggle with focus.",
    luckyNumbers: [3, 5, 8],
    luckyColors: ["Yellow", "Blue", "Green"],
    luckyNumber: 5,
    luckyColor: "Yellow",
    mood: "Curious",
    compatibility: "Sagittarius",
    dailyHoroscope:
      "Your mind is especially sharp today, making this an excellent time for communication, learning, and social connections. You may find yourself juggling multiple interests or conversations, but your adaptability allows you to handle it with grace. An unexpected message could bring exciting news.",
    loveHoroscope:
      "Your charm and wit make you irresistible in romantic situations today. Partners appreciate your intellectual stimulation and playful banter. Single Geminis might find themselves drawn to someone who can keep up with their mental agility.",
    careerHoroscope:
      "Your versatility shines in the workplace today. You excel at tasks requiring communication, problem-solving, and multitasking. Consider ways to incorporate more variety into your daily work routine.",
    healthHoroscope:
      "Pay attention to your respiratory system and arms, which are ruled by Gemini. Deep breathing exercises would be beneficial today. Your connection to the air element suggests activities that stimulate both mind and body, like dancing or team sports.",
  },
  {
    id: "cancer",
    name: "Cancer",
    symbol: "♋",
    symbolName: "The Crab",
    dates: "June 21 - July 22",
    element: "Water",
    quality: "Cardinal",
    rulingPlanet: "Moon",
    traits: ["Tenacious", "Highly Imaginative", "Loyal", "Emotional", "Sympathetic"],
    strengths:
      "Cancers are deeply intuitive, emotional, and caring. They're fiercely loyal to family and friends, with a strong protective instinct.",
    weaknesses:
      "Can be moody, pessimistic, and suspicious. May be overly sensitive and reluctant to directly confront problems.",
    luckyNumbers: [2, 7, 11],
    luckyColors: ["White", "Silver", "Blue"],
    luckyNumber: 2,
    luckyColor: "Silver",
    mood: "Nurturing",
    compatibility: "Capricorn",
    dailyHoroscope:
      "Your intuition is heightened today, providing valuable insights into both personal and professional matters. Home and family take center stage, making this a good time to nurture relationships and create a comfortable environment. Your emotional sensitivity allows you to connect deeply with others. Trust your instincts regarding a financial decision.",
    loveHoroscope:
      "Your nurturing nature creates a safe space for emotional intimacy today. Partners feel deeply cared for in your presence. Single Cancers might find themselves attracted to someone who appreciates their sensitivity and protective qualities.",
    careerHoroscope:
      "Your intuitive understanding of others' needs makes you a valuable team member today. You excel at creating a supportive work environment and anticipating problems before they arise. Consider ways to incorporate more emotional fulfillment into your career path.",
    healthHoroscope:
      "Focus on digestive health today, as the stomach area is ruled by Cancer. Comfort foods prepared with care can be nourishing. Your connection to the water element suggests swimming or a warm bath would be particularly restorative.",
  },
  {
    id: "leo",
    name: "Leo",
    symbol: "♌",
    symbolName: "The Lion",
    dates: "July 23 - August 22",
    element: "Fire",
    quality: "Fixed",
    rulingPlanet: "Sun",
    traits: ["Creative", "Passionate", "Generous", "Warm-hearted", "Cheerful"],
    strengths:
      "Leos are creative, passionate, and generous. They have natural leadership abilities and a flair for the dramatic that draws others to them.",
    weaknesses: "Can be arrogant, stubborn, and self-centered. May have a tendency to be domineering and inflexible.",
    luckyNumbers: [1, 5, 9],
    luckyColors: ["Gold", "Orange", "Red"],
    luckyNumber: 1,
    luckyColor: "Gold",
    mood: "Confident",
    compatibility: "Aquarius",
    dailyHoroscope:
      "Your natural charisma is especially powerful today, drawing others to your warmth and confidence. Creative endeavors are favored, making this an excellent time to express yourself artistically or take the lead on innovative projects. Recognition for past efforts may come your way. Embrace opportunities to shine without overshadowing others.",
    loveHoroscope:
      "Your generous heart and passionate nature create magnetic romantic energy today. Partners appreciate your loyalty and enthusiasm. Single Leos might find themselves attracting admirers through their authentic self-expression and confidence.",
    careerHoroscope:
      "Your leadership abilities are highlighted in the workplace today. You excel at inspiring others and bringing creative solutions to problems. Consider ways to gain more recognition for your contributions.",
    healthHoroscope:
      "Pay attention to your heart and back, which are ruled by Leo. Cardiovascular exercise would be particularly beneficial today. Your connection to the fire element suggests activities that allow you to express yourself physically, like dance or sports that showcase your abilities.",
  },
  {
    id: "virgo",
    name: "Virgo",
    symbol: "♍",
    symbolName: "The Maiden",
    dates: "August 23 - September 22",
    element: "Earth",
    quality: "Mutable",
    rulingPlanet: "Mercury",
    traits: ["Loyal", "Analytical", "Kind", "Hardworking", "Practical"],
    strengths:
      "Virgos are analytical, practical, and attentive to detail. They're hardworking, reliable, and have a deep sense of humanity.",
    weaknesses:
      "Can be overly critical, worry too much, and be excessively concerned with cleanliness and order. May be too perfectionistic.",
    luckyNumbers: [3, 6, 7],
    luckyColors: ["Green", "Brown", "Cream"],
    luckyNumber: 7,
    luckyColor: "Navy Blue",
    mood: "Analytical",
    compatibility: "Pisces",
    dailyHoroscope:
      "Your analytical skills are particularly sharp today, allowing you to solve problems with precision and efficiency. Attention to detail serves you well in both personal and professional spheres. Your practical nature helps you implement improvements to daily routines. Take time to appreciate small accomplishments rather than focusing only on what needs fixing.",
    loveHoroscope:
      "Your thoughtful gestures and practical support create a foundation of trust in relationships today. Partners appreciate your attentiveness to their needs. Single Virgos might find connection through shared interests in health, service, or intellectual pursuits.",
    careerHoroscope:
      "Your methodical approach and eye for detail make you invaluable in the workplace today. You excel at organizing information and improving systems. Consider ways to apply your analytical skills to advance your career goals.",
    healthHoroscope:
      "Focus on digestive health today, as the intestinal area is ruled by Virgo. A clean diet with plenty of fiber would be beneficial. Your connection to the earth element suggests grounding practices like yoga or mindful walking would help balance your tendency to overthink.",
  },
  {
    id: "libra",
    name: "Libra",
    symbol: "♎",
    symbolName: "The Scales",
    dates: "September 23 - October 22",
    element: "Air",
    quality: "Cardinal",
    rulingPlanet: "Venus",
    traits: ["Diplomatic", "Fair-minded", "Social", "Cooperative", "Gracious"],
    strengths:
      "Libras are cooperative, diplomatic, and fair-minded. They value harmony and balance, with a strong sense of justice and beauty.",
    weaknesses:
      "Can be indecisive, avoidant of confrontation, and self-pitying. May carry grudges and be too concerned with pleasing others.",
    luckyNumbers: [4, 6, 13],
    luckyColors: ["Pink", "Blue", "White"],
    luckyNumber: 4,
    luckyColor: "Pink",
    mood: "Harmonious",
    compatibility: "Aries",
    dailyHoroscope:
      "Your diplomatic skills help you navigate social situations with grace today. Relationships of all kinds are highlighted, making this an excellent time to strengthen connections or resolve conflicts. Your appreciation for beauty and harmony inspires creative solutions to problems. Balance work responsibilities with personal pleasures for optimal wellbeing.",
    loveHoroscope:
      "Your charm and desire for harmony create a peaceful atmosphere in romantic relationships today. Partners appreciate your willingness to see their perspective. Single Libras might find themselves attracted to someone who embodies balance and fairness.",
    careerHoroscope:
      "Your ability to see all sides of a situation makes you an excellent mediator in the workplace today. You excel at creating harmonious team dynamics and finding fair compromises. Consider ways to incorporate more beauty and balance into your work environment.",
    healthHoroscope:
      "Pay attention to your kidneys and lower back, which are ruled by Libra. Staying well-hydrated would be particularly beneficial today. Your connection to the air element suggests activities that promote balance between mind and body, like tai chi or dance.",
  },
  {
    id: "scorpio",
    name: "Scorpio",
    symbol: "♏",
    symbolName: "The Scorpion",
    dates: "October 23 - November 21",
    element: "Water",
    quality: "Fixed",
    rulingPlanet: "Pluto, Mars",
    traits: ["Resourceful", "Brave", "Passionate", "Stubborn", "Intense"],
    strengths:
      "Scorpios are resourceful, passionate, and brave. They have powerful emotional depths, strong willpower, and are fiercely loyal to those they trust.",
    weaknesses:
      "Can be distrusting, jealous, secretive, and resentful. May be too controlling and struggle with forgiveness.",
    luckyNumbers: [8, 11, 18],
    luckyColors: ["Black", "Red", "Purple"],
    luckyNumber: 8,
    luckyColor: "Deep Red",
    mood: "Intense",
    compatibility: "Taurus",
    dailyHoroscope:
      "Your intuitive insights reveal hidden truths today, giving you an edge in complex situations. Transformation is highlighted, making this a powerful time for personal growth and releasing what no longer serves you. Your intensity and focus allow you to delve deeply into subjects that others might avoid. Trust your instincts regarding someone's true intentions.",
    loveHoroscope:
      "Your passionate nature and emotional depth create powerful connections in relationships today. Partners appreciate your loyalty and ability to see beyond surface appearances. Single Scorpios might find themselves drawn to someone who isn't afraid of authentic intimacy.",
    careerHoroscope:
      "Your investigative abilities and determination make you a formidable presence in the workplace today. You excel at uncovering solutions to complex problems and seeing through pretenses. Consider ways to use your transformative energy to advance your career goals.",
    healthHoroscope:
      "Focus on reproductive and elimination systems today, as these areas are ruled by Scorpio. Detoxifying practices would be particularly beneficial. Your connection to the water element suggests swimming or steam baths could help release emotional tension stored in the body.",
  },
  {
    id: "sagittarius",
    name: "Sagittarius",
    symbol: "♐",
    symbolName: "The Archer",
    dates: "November 22 - December 21",
    element: "Fire",
    quality: "Mutable",
    rulingPlanet: "Jupiter",
    traits: ["Generous", "Idealistic", "Humorous", "Adventurous", "Enthusiastic"],
    strengths:
      "Sagittarians are generous, idealistic, and have a great sense of humor. They're adventurous, enthusiastic, and have a love for freedom and exploration.",
    weaknesses:
      "Can be tactless, restless, and overconfident. May make promises they can't keep and be too blunt with others.",
    luckyNumbers: [3, 7, 9],
    luckyColors: ["Blue", "Purple", "Red"],
    luckyNumber: 3,
    luckyColor: "Blue",
    mood: "Optimistic",
    compatibility: "Gemini",
    dailyHoroscope:
      "Your optimistic outlook opens doors to new possibilities today. Travel or educational pursuits are favored, making this an excellent time to expand your horizons through study or exploration. Your philosophical nature helps you see the bigger picture in challenging situations. An unexpected opportunity for adventure may present itself.",
    loveHoroscope:
      "Your enthusiasm and honesty create refreshing energy in romantic relationships today. Partners appreciate your willingness to explore new experiences together. Single Sagittarians might find connection through shared philosophical interests or during travels.",
    careerHoroscope:
      "Your visionary thinking and positive attitude make you an inspiring presence in the workplace today. You excel at seeing future possibilities and motivating others to reach for higher goals. Consider ways to incorporate more meaning and adventure into your career path.",
    healthHoroscope:
      "Pay attention to your hips and thighs, which are ruled by Sagittarius. Activities that allow for freedom of movement would be particularly beneficial today. Your connection to the fire element suggests outdoor adventures or sports that challenge you physically would help channel your abundant energy.",
  },
  {
    id: "capricorn",
    name: "Capricorn",
    symbol: "♑",
    symbolName: "The Goat",
    dates: "December 22 - January 19",
    element: "Earth",
    quality: "Cardinal",
    rulingPlanet: "Saturn",
    traits: ["Responsible", "Disciplined", "Self-controlled", "Good managers", "Practical"],
    strengths:
      "Capricorns are responsible, disciplined, and have excellent self-control. They're good managers with practical wisdom and a strong sense of tradition.",
    weaknesses:
      "Can be know-it-alls, unforgiving, condescending, and expecting the worst. May be too focused on work and status.",
    luckyNumbers: [4, 8, 13],
    luckyColors: ["Brown", "Black", "Dark Green"],
    luckyNumber: 10,
    luckyColor: "Brown",
    mood: "Determined",
    compatibility: "Cancer",
    dailyHoroscope:
      "Your disciplined approach helps you make significant progress toward long-term goals today. Professional matters are highlighted, making this a good time to focus on career advancement or business planning. Your practical wisdom allows you to build solid foundations for future success. Recognition for your hard work may come from an unexpected source.",
    loveHoroscope:
      "Your reliability and commitment create a sense of security in relationships today. Partners appreciate your steady presence and practical expressions of care. Single Capricorns might find connection through shared ambitions or values around responsibility.",
    careerHoroscope:
      "Your organizational abilities and work ethic make you a respected figure in the workplace today. You excel at creating structures that stand the test of time. Consider ways to balance professional ambitions with personal fulfillment.",
    healthHoroscope:
      "Focus on bone and joint health today, as the skeletal system is ruled by Capricorn. Weight-bearing exercise would be particularly beneficial. Your connection to the earth element suggests grounding practices like hiking on natural terrain or gardening would help balance your tendency toward overwork.",
  },
  {
    id: "aquarius",
    name: "Aquarius",
    symbol: "♒",
    symbolName: "The Water Bearer",
    dates: "January 20 - February 18",
    element: "Air",
    quality: "Fixed",
    rulingPlanet: "Uranus, Saturn",
    traits: ["Progressive", "Original", "Independent", "Humanitarian", "Inventive"],
    strengths:
      "Aquarians are progressive, original, and independent. They're humanitarian with strong ideals and an inventive, analytical mind.",
    weaknesses:
      "Can be temperamental, uncompromising, aloof, and emotionally detached. May run from emotional expression.",
    luckyNumbers: [4, 7, 11],
    luckyColors: ["Blue", "Turquoise", "Silver"],
    luckyNumber: 11,
    luckyColor: "Electric Blue",
    mood: "Innovative",
    compatibility: "Leo",
    dailyHoroscope:
      "Your innovative thinking generates brilliant solutions to long-standing problems today. Social connections and group endeavors are highlighted, making this an excellent time to collaborate on humanitarian projects or network with like-minded individuals. Your unique perspective allows you to see possibilities others miss. An unexpected technological development may benefit your work or personal life.",
    loveHoroscope:
      "Your intellectual connection with partners creates stimulating relationship dynamics today. Others appreciate your respect for independence within togetherness. Single Aquarians might find themselves attracted to someone who shares their vision for a better future.",
    careerHoroscope:
      "Your forward-thinking approach and technological aptitude make you a valuable asset in the workplace today. You excel at finding unconventional solutions and bringing fresh perspectives to team projects. Consider ways to align your career with your humanitarian values.",
    healthHoroscope:
      "Pay attention to circulation and ankle strength today, as these areas are ruled by Aquarius. Activities that promote blood flow would be particularly beneficial. Your connection to the air element suggests mental stimulation combined with physical movement, like learning a new sport or dance style, would help balance your energy.",
  },
  {
    id: "pisces",
    name: "Pisces",
    symbol: "♓",
    symbolName: "The Fish",
    dates: "February 19 - March 20",
    element: "Water",
    quality: "Mutable",
    rulingPlanet: "Neptune, Jupiter",
    traits: ["Compassionate", "Artistic", "Intuitive", "Gentle", "Wise"],
    strengths:
      "Pisceans are compassionate, artistic, and intuitive. They're gentle, wise, and have a strong connection to music and artistic expression.",
    weaknesses:
      "Can be fearful, overly trusting, sad, desire to escape reality, and self-pitying. May be prone to victimhood.",
    luckyNumbers: [3, 9, 12],
    luckyColors: ["Sea Green", "Lavender", "Purple"],
    luckyNumber: 12,
    luckyColor: "Lavender",
    mood: "Dreamy",
    compatibility: "Virgo",
    dailyHoroscope:
      "Your intuitive insights provide guidance in navigating emotional waters today. Creative and spiritual pursuits are favored, making this an excellent time for artistic expression or meditation. Your compassionate nature allows you to connect deeply with others' feelings. Pay attention to dreams and subtle messages from your subconscious.",
    loveHoroscope:
      "Your empathetic understanding creates a magical atmosphere in romantic relationships today. Partners feel truly seen and accepted in your presence. Single Pisceans might find connection through shared artistic interests or spiritual practices.",
    careerHoroscope:
      "Your creative vision and intuitive understanding of others make you a healing presence in the workplace today. You excel at roles requiring empathy and imagination. Consider ways to incorporate more artistic or spiritual elements into your career path.",
    healthHoroscope:
      "Focus on foot care and immune system support today, as these areas are ruled by Pisces. Gentle water-based activities would be particularly beneficial. Your connection to the water element suggests swimming, floating, or simply soaking in a bath with essential oils would help restore your sensitive energy field.",
  },
]

export const compatibilityData = [
  {
    sign1: "aries",
    sign2: "aries",
    score: 70,
    description:
      "Two Aries together create a passionate and energetic relationship. You both understand each other's need for independence and adventure. However, your shared impulsiveness and competitive nature can lead to power struggles. Success depends on learning to take turns leading and developing patience with each other's strong personalities.",
  },
  {
    sign1: "aries",
    sign2: "taurus",
    score: 45,
    description:
      "Aries and Taurus create a challenging but potentially rewarding match. Aries' spontaneity clashes with Taurus' need for stability and routine. However, you can balance each other well if Aries appreciates Taurus' reliability, while Taurus admires Aries' courage and initiative. Patience and compromise are essential for this relationship to thrive.",
  },
  {
    sign1: "aries",
    sign2: "gemini",
    score: 85,
    description:
      "Aries and Gemini form an exciting and dynamic partnership. You both enjoy variety, new experiences, and intellectual stimulation. Aries provides the initiative while Gemini contributes adaptability and fresh ideas. This relationship stays interesting as you inspire each other's curiosity and adventurous spirit. Communication flows easily between you.",
  },
  {
    sign1: "aries",
    sign2: "cancer",
    score: 40,
    description:
      "Aries and Cancer create a challenging match that requires significant adjustment. Aries' directness can hurt sensitive Cancer, while Cancer's emotional needs may feel restrictive to independent Aries. However, when balanced, Aries provides protection and courage while Cancer offers emotional depth and nurturing. Success requires Aries to develop sensitivity and Cancer to become more resilient.",
  },
  {
    sign1: "aries",
    sign2: "leo",
    score: 90,
    description:
      "Aries and Leo create a passionate and exciting fire sign match. You share enthusiasm, creativity, and a love of adventure. Both signs appreciate honesty and direct communication. Leo's loyalty complements Aries' pioneering spirit. While you may compete for attention at times, your mutual respect and admiration create a strong foundation for a dynamic relationship.",
  },
  {
    sign1: "aries",
    sign2: "virgo",
    score: 35,
    description:
      "Aries and Virgo face significant compatibility challenges. Aries' impulsiveness clashes with Virgo's careful planning and analysis. Virgo may find Aries careless, while Aries sees Virgo as too critical. However, if you appreciate your differences, Aries can learn precision from Virgo, while Virgo gains spontaneity from Aries. This relationship requires patience and understanding.",
  },
  {
    sign1: "aries",
    sign2: "libra",
    score: 75,
    description:
      "Aries and Libra create an intriguing opposites-attract relationship. As opposing signs in the zodiac, you naturally balance each other. Aries brings decisiveness and action, while Libra contributes diplomacy and consideration. You both value honesty and fairness. Challenges arise when Aries' directness overwhelms Libra's desire for harmony, but with communication, you create a dynamic and balanced partnership.",
  },
  {
    sign1: "aries",
    sign2: "scorpio",
    score: 65,
    description:
      "Aries and Scorpio create an intense and passionate relationship. Both signs are ruled by Mars, giving you shared determination and courage. Your connection features strong physical chemistry and emotional depth. Challenges arise from your different approaches to power—Aries is direct while Scorpio operates more strategically. Trust issues may emerge if Aries seems too independent for Scorpio's liking.",
  },
  {
    sign1: "aries",
    sign2: "sagittarius",
    score: 95,
    description:
      "Aries and Sagittarius form an excellent fire sign match with high compatibility. You share a love of adventure, optimism, and straightforward communication. Neither sign is possessive, allowing for the independence you both crave. Your relationship stays exciting as you encourage each other's dreams and explorations. Minor challenges arise only when competing for attention or leadership.",
  },
  {
    sign1: "aries",
    sign2: "capricorn",
    score: 40,
    description:
      "Aries and Capricorn create a challenging but potentially complementary relationship. Aries' spontaneity contrasts with Capricorn's careful planning. Capricorn may find Aries too impulsive, while Aries sees Capricorn as too serious. However, you can balance each other well—Aries brings excitement and initiative, while Capricorn contributes stability and practical wisdom. Success requires mutual respect for your different approaches to life.",
  },
  {
    sign1: "aries",
    sign2: "aquarius",
    score: 80,
    description:
      "Aries and Aquarius form an exciting and stimulating partnership. You both value independence, honesty, and innovation. Aries brings passion and initiative, while Aquarius contributes vision and originality. Your relationship stays interesting as you inspire each other's ideals and ambitions. Challenges arise only when Aries' emotional needs clash with Aquarius' more detached approach to feelings.",
  },
  {
    sign1: "aries",
    sign2: "pisces",
    score: 50,
    description:
      "Aries and Pisces create an intriguing blend of fire and water. Aries' directness contrasts with Pisces' sensitivity and intuition. Pisces can find Aries too aggressive, while Aries may see Pisces as too passive or evasive. However, you can complement each other beautifully—Aries provides protection and decisiveness, while Pisces offers emotional depth and compassion. This relationship requires Aries to develop gentleness and Pisces to become more assertive.",
  },
  {
    sign1: "taurus",
    sign2: "taurus",
    score: 90,
    description:
      "Two Taurus partners create a stable and harmonious relationship built on shared values. You understand each other's need for security, comfort, and loyalty. Your practical approach to life helps you build something lasting together. Challenges arise only from shared stubbornness when disagreements occur. Remember to introduce variety occasionally to prevent the relationship from becoming too routine.",
  },
  {
    sign1: "taurus",
    sign2: "gemini",
    score: 35,
    description:
      "Taurus and Gemini face significant compatibility challenges due to different approaches to life. Taurus values stability and routine, while Gemini craves variety and mental stimulation. Taurus may find Gemini too scattered, while Gemini sees Taurus as too rigid. Success requires Taurus to embrace more flexibility and Gemini to develop more consistency. Your different perspectives can be complementary if you appreciate what each brings to the relationship.",
  },
  {
    sign1: "taurus",
    sign2: "cancer",
    score: 95,
    description:
      "Taurus and Cancer create a deeply compatible and nurturing relationship. You both value security, loyalty, and creating a comfortable home. Cancer's emotional intuition complements Taurus' practicality and steadfastness. You understand each other's need for reassurance and are willing to provide it. This relationship has excellent potential for long-term happiness and mutual support.",
  },
  {
    sign1: "taurus",
    sign2: "leo",
    score: 55,
    description:
      "Taurus and Leo create a relationship with both challenges and rewards. You share a love of pleasure, comfort, and loyalty once committed. However, Leo's need for attention and drama may clash with Taurus' preference for calm and stability. Taurus' stubbornness can frustrate Leo's pride. Success requires Leo to appreciate Taurus' reliability, while Taurus admires Leo's warmth and creativity.",
  },
]

