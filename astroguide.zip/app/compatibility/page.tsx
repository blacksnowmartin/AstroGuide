"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { zodiacSigns, compatibilityData } from "@/lib/zodiac-data"
import { HeartIcon, InfoIcon } from "lucide-react"
import { motion } from "framer-motion"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"

export default function CompatibilityPage() {
  const [sign1, setSign1] = useState("")
  const [sign2, setSign2] = useState("")
  const [showResult, setShowResult] = useState(false)

  const handleCheckCompatibility = () => {
    if (sign1 && sign2) {
      setShowResult(true)
    }
  }

  const resetForm = () => {
    setSign1("")
    setSign2("")
    setShowResult(false)
  }

  const getCompatibilityScore = () => {
    if (!sign1 || !sign2) return null

    const pair = compatibilityData.find(
      (data) => (data.sign1 === sign1 && data.sign2 === sign2) || (data.sign1 === sign2 && data.sign2 === sign1),
    )

    return pair ? pair.score : 50 // Default to 50% if not found
  }

  const getCompatibilityDescription = () => {
    if (!sign1 || !sign2) return null

    const pair = compatibilityData.find(
      (data) => (data.sign1 === sign1 && data.sign2 === sign2) || (data.sign1 === sign2 && data.sign2 === sign1),
    )

    return pair
      ? pair.description
      : "These signs have a moderate compatibility. While there may be some challenges, with understanding and communication, this relationship can work well."
  }

  const score = getCompatibilityScore()
  const description = getCompatibilityDescription()

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-500"
    if (score >= 60) return "text-blue-500"
    if (score >= 40) return "text-yellow-500"
    return "text-red-500"
  }

  const getScoreText = (score: number) => {
    if (score >= 80) return "Excellent Match"
    if (score >= 60) return "Good Match"
    if (score >= 40) return "Average Match"
    return "Challenging Match"
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/80">
      <Navbar />

      <main className="container mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-bold mb-4">Zodiac Compatibility</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Discover how compatible you are with your partner, friend, or colleague based on your zodiac signs.
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>Compatibility Check</CardTitle>
              <CardDescription>Select two zodiac signs to check their compatibility</CardDescription>
            </CardHeader>
            <CardContent>
              {!showResult ? (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Your Zodiac Sign</label>
                      <Select value={sign1} onValueChange={setSign1}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select your sign" />
                        </SelectTrigger>
                        <SelectContent>
                          {zodiacSigns.map((sign) => (
                            <SelectItem key={sign.id} value={sign.id}>
                              <span className="mr-2">{sign.symbol}</span> {sign.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">Their Zodiac Sign</label>
                      <Select value={sign2} onValueChange={setSign2}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select their sign" />
                        </SelectTrigger>
                        <SelectContent>
                          {zodiacSigns.map((sign) => (
                            <SelectItem key={sign.id} value={sign.id}>
                              <span className="mr-2">{sign.symbol}</span> {sign.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <Button className="w-full" size="lg" onClick={handleCheckCompatibility} disabled={!sign1 || !sign2}>
                    <HeartIcon className="mr-2 h-5 w-5" />
                    Check Compatibility
                  </Button>
                </div>
              ) : (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.5 }}
                  className="space-y-6"
                >
                  <div className="flex justify-center items-center space-x-6">
                    <div className="text-center">
                      <div className="text-5xl mb-2">{zodiacSigns.find((s) => s.id === sign1)?.symbol}</div>
                      <div className="font-medium">{zodiacSigns.find((s) => s.id === sign1)?.name}</div>
                    </div>

                    <div className="relative">
                      <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center">
                        <HeartIcon className="h-8 w-8 text-primary" />
                      </div>
                      <div className="absolute -bottom-2 -right-2 bg-background rounded-full px-2 py-1 text-xs font-bold border border-border">
                        {score}%
                      </div>
                    </div>

                    <div className="text-center">
                      <div className="text-5xl mb-2">{zodiacSigns.find((s) => s.id === sign2)?.symbol}</div>
                      <div className="font-medium">{zodiacSigns.find((s) => s.id === sign2)?.name}</div>
                    </div>
                  </div>

                  <div className="text-center">
                    <h3 className={`text-2xl font-bold mb-2 ${getScoreColor(score || 0)}`}>
                      {getScoreText(score || 0)}
                    </h3>
                    <p className="text-muted-foreground">{description}</p>
                  </div>

                  <div className="bg-muted/30 p-4 rounded-lg">
                    <div className="flex items-start">
                      <InfoIcon className="h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                      <div>
                        <h4 className="font-medium mb-1">Compatibility Insights</h4>
                        <p className="text-sm text-muted-foreground">
                          {sign1 && sign2 && (
                            <>
                              {zodiacSigns.find((s) => s.id === sign1)?.name} (
                              {zodiacSigns.find((s) => s.id === sign1)?.element}) and{" "}
                              {zodiacSigns.find((s) => s.id === sign2)?.name} (
                              {zodiacSigns.find((s) => s.id === sign2)?.element}) have unique dynamics that influence
                              their relationship. Consider these insights as general guidance rather than absolute
                              rules.
                            </>
                          )}
                        </p>
                      </div>
                    </div>
                  </div>

                  <Button variant="outline" className="w-full" onClick={resetForm}>
                    Check Another Compatibility
                  </Button>
                </motion.div>
              )}
            </CardContent>
          </Card>

          <div className="mt-12">
            <h2 className="text-2xl font-bold mb-6 text-center">Understanding Zodiac Compatibility</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Elements & Compatibility</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="mb-4 text-muted-foreground">
                    Zodiac signs are grouped into four elements, which play a significant role in determining
                    compatibility:
                  </p>
                  <ul className="space-y-2">
                    <li className="flex items-center">
                      <span className="w-3 h-3 rounded-full bg-orange-500 mr-2"></span>
                      <span className="font-medium">Fire Signs</span>
                      <span className="text-muted-foreground ml-2">(Aries, Leo, Sagittarius)</span>
                    </li>
                    <li className="flex items-center">
                      <span className="w-3 h-3 rounded-full bg-green-500 mr-2"></span>
                      <span className="font-medium">Earth Signs</span>
                      <span className="text-muted-foreground ml-2">(Taurus, Virgo, Capricorn)</span>
                    </li>
                    <li className="flex items-center">
                      <span className="w-3 h-3 rounded-full bg-blue-400 mr-2"></span>
                      <span className="font-medium">Air Signs</span>
                      <span className="text-muted-foreground ml-2">(Gemini, Libra, Aquarius)</span>
                    </li>
                    <li className="flex items-center">
                      <span className="w-3 h-3 rounded-full bg-indigo-400 mr-2"></span>
                      <span className="font-medium">Water Signs</span>
                      <span className="text-muted-foreground ml-2">(Cancer, Scorpio, Pisces)</span>
                    </li>
                  </ul>
                  <p className="mt-4 text-muted-foreground">
                    Generally, signs of the same element tend to be compatible, as do complementary elements: Fire with
                    Air, and Earth with Water.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Qualities & Compatibility</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="mb-4 text-muted-foreground">
                    Each zodiac sign also belongs to one of three qualities (or modalities), which influence how they
                    interact:
                  </p>
                  <ul className="space-y-2">
                    <li>
                      <span className="font-medium">Cardinal Signs</span>
                      <span className="text-muted-foreground ml-2">(Aries, Cancer, Libra, Capricorn)</span>
                      <p className="text-sm text-muted-foreground mt-1">
                        Initiators who like to lead and start new things.
                      </p>
                    </li>
                    <li>
                      <span className="font-medium">Fixed Signs</span>
                      <span className="text-muted-foreground ml-2">(Taurus, Leo, Scorpio, Aquarius)</span>
                      <p className="text-sm text-muted-foreground mt-1">
                        Stable and persistent, they maintain what's already established.
                      </p>
                    </li>
                    <li>
                      <span className="font-medium">Mutable Signs</span>
                      <span className="text-muted-foreground ml-2">(Gemini, Virgo, Sagittarius, Pisces)</span>
                      <p className="text-sm text-muted-foreground mt-1">
                        Adaptable and flexible, they're comfortable with change.
                      </p>
                    </li>
                  </ul>
                  <p className="mt-4 text-muted-foreground">
                    Signs of the same quality may face challenges as they share similar approaches, while different
                    qualities can complement each other.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}

