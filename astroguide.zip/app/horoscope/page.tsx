"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { zodiacSigns } from "@/lib/zodiac-data"
import { RefreshCwIcon } from "lucide-react"
import { motion } from "framer-motion"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"

export default function HoroscopePage() {
  const [selectedSign, setSelectedSign] = useState("aries")
  const [isRefreshing, setIsRefreshing] = useState(false)

  const refreshHoroscope = () => {
    setIsRefreshing(true)
    setTimeout(() => {
      setIsRefreshing(false)
    }, 1000)
  }

  const currentSign = zodiacSigns.find((sign) => sign.id === selectedSign)

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/80">
      <Navbar />

      <main className="container mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-bold mb-4">Daily Horoscope</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Discover what the stars have in store for you today. Select your zodiac sign to read your personalized daily
            horoscope.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle>Choose Your Sign</CardTitle>
              <CardDescription>Select your zodiac sign to view your daily horoscope</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="aries" onValueChange={setSelectedSign}>
                <TabsList className="grid grid-cols-3 mb-4">
                  <TabsTrigger value="fire" className="font-semibold">
                    Fire
                  </TabsTrigger>
                  <TabsTrigger value="earth" className="font-semibold">
                    Earth
                  </TabsTrigger>
                  <TabsTrigger value="air" className="font-semibold">
                    Air
                  </TabsTrigger>
                  <TabsTrigger value="water" className="font-semibold">
                    Water
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="fire" className="mt-0">
                  <div className="grid grid-cols-1 gap-2">
                    {zodiacSigns
                      .filter((sign) => sign.element === "Fire")
                      .map((sign) => (
                        <Button
                          key={sign.id}
                          variant={selectedSign === sign.id ? "default" : "outline"}
                          className="justify-start h-auto py-3"
                          onClick={() => setSelectedSign(sign.id)}
                        >
                          <span className="mr-2 text-xl">{sign.symbol}</span>
                          <div className="text-left">
                            <div className="font-medium">{sign.name}</div>
                            <div className="text-xs text-muted-foreground">{sign.dates}</div>
                          </div>
                        </Button>
                      ))}
                  </div>
                </TabsContent>

                <TabsContent value="earth" className="mt-0">
                  <div className="grid grid-cols-1 gap-2">
                    {zodiacSigns
                      .filter((sign) => sign.element === "Earth")
                      .map((sign) => (
                        <Button
                          key={sign.id}
                          variant={selectedSign === sign.id ? "default" : "outline"}
                          className="justify-start h-auto py-3"
                          onClick={() => setSelectedSign(sign.id)}
                        >
                          <span className="mr-2 text-xl">{sign.symbol}</span>
                          <div className="text-left">
                            <div className="font-medium">{sign.name}</div>
                            <div className="text-xs text-muted-foreground">{sign.dates}</div>
                          </div>
                        </Button>
                      ))}
                  </div>
                </TabsContent>

                <TabsContent value="air" className="mt-0">
                  <div className="grid grid-cols-1 gap-2">
                    {zodiacSigns
                      .filter((sign) => sign.element === "Air")
                      .map((sign) => (
                        <Button
                          key={sign.id}
                          variant={selectedSign === sign.id ? "default" : "outline"}
                          className="justify-start h-auto py-3"
                          onClick={() => setSelectedSign(sign.id)}
                        >
                          <span className="mr-2 text-xl">{sign.symbol}</span>
                          <div className="text-left">
                            <div className="font-medium">{sign.name}</div>
                            <div className="text-xs text-muted-foreground">{sign.dates}</div>
                          </div>
                        </Button>
                      ))}
                  </div>
                </TabsContent>

                <TabsContent value="water" className="mt-0">
                  <div className="grid grid-cols-1 gap-2">
                    {zodiacSigns
                      .filter((sign) => sign.element === "Water")
                      .map((sign) => (
                        <Button
                          key={sign.id}
                          variant={selectedSign === sign.id ? "default" : "outline"}
                          className="justify-start h-auto py-3"
                          onClick={() => setSelectedSign(sign.id)}
                        >
                          <span className="mr-2 text-xl">{sign.symbol}</span>
                          <div className="text-left">
                            <div className="font-medium">{sign.name}</div>
                            <div className="text-xs text-muted-foreground">{sign.dates}</div>
                          </div>
                        </Button>
                      ))}
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          <Card className="lg:col-span-2">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="flex items-center">
                  <span className="text-2xl mr-2">{currentSign?.symbol}</span>
                  {currentSign?.name}
                </CardTitle>
                <CardDescription>{currentSign?.dates}</CardDescription>
              </div>
              <Button
                variant="outline"
                size="icon"
                onClick={refreshHoroscope}
                className={isRefreshing ? "animate-spin" : ""}
              >
                <RefreshCwIcon className="h-4 w-4" />
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">Today's Horoscope</h3>
                  <p className="text-muted-foreground">{currentSign?.dailyHoroscope}</p>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className="bg-muted/30 p-4 rounded-lg text-center">
                    <div className="text-sm text-muted-foreground">Lucky Number</div>
                    <div className="text-xl font-semibold">{currentSign?.luckyNumber}</div>
                  </div>
                  <div className="bg-muted/30 p-4 rounded-lg text-center">
                    <div className="text-sm text-muted-foreground">Lucky Color</div>
                    <div className="text-xl font-semibold">{currentSign?.luckyColor}</div>
                  </div>
                  <div className="bg-muted/30 p-4 rounded-lg text-center">
                    <div className="text-sm text-muted-foreground">Mood</div>
                    <div className="text-xl font-semibold">{currentSign?.mood}</div>
                  </div>
                  <div className="bg-muted/30 p-4 rounded-lg text-center">
                    <div className="text-sm text-muted-foreground">Compatibility</div>
                    <div className="text-xl font-semibold">{currentSign?.compatibility}</div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Love & Relationships</h3>
                  <p className="text-muted-foreground">{currentSign?.loveHoroscope}</p>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Career & Money</h3>
                  <p className="text-muted-foreground">{currentSign?.careerHoroscope}</p>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Health & Wellness</h3>
                  <p className="text-muted-foreground">{currentSign?.healthHoroscope}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  )
}

