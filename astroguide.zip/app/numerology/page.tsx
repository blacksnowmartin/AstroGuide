"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { motion } from "framer-motion"
import { CalculatorIcon, InfoIcon } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import { lifePathData } from "@/lib/numerology-data"

export default function NumerologyPage() {
  const [birthdate, setBirthdate] = useState("")
  const [lifePathNumber, setLifePathNumber] = useState<number | null>(null)
  const [calculationSteps, setCalculationSteps] = useState<string[]>([])
  const [error, setError] = useState("")

  const calculateLifePathNumber = () => {
    setError("")

    // Validate date format
    const dateRegex = /^\d{4}-\d{2}-\d{2}$/
    if (!dateRegex.test(birthdate)) {
      setError("Please enter a valid date in YYYY-MM-DD format")
      return
    }

    const [year, month, day] = birthdate.split("-").map((part) => Number.parseInt(part, 10))

    // Validate date values
    const dateObj = new Date(year, month - 1, day)
    if (dateObj.getFullYear() !== year || dateObj.getMonth() !== month - 1 || dateObj.getDate() !== day) {
      setError("Please enter a valid date")
      return
    }

    // Calculate Life Path Number
    const steps: string[] = []

    // Step 1: Add up the digits in the month
    const monthSum = sumDigits(month)
    steps.push(`Month (${month}): ${month >= 10 ? `${month} → ${monthSum}` : monthSum}`)

    // Step 2: Add up the digits in the day
    const daySum = sumDigits(day)
    steps.push(`Day (${day}): ${day >= 10 ? `${day} → ${daySum}` : daySum}`)

    // Step 3: Add up the digits in the year
    const yearString = year.toString()
    let yearCalc = `${yearString}`
    const yearSum = sumDigits(year)
    if (yearSum !== year) {
      yearCalc += ` → ${yearSum}`
    }
    steps.push(`Year (${year}): ${yearCalc}`)

    // Step 4: Add the reduced month, day, and year
    const totalSum = monthSum + daySum + yearSum
    steps.push(`Month + Day + Year: ${monthSum} + ${daySum} + ${yearSum} = ${totalSum}`)

    // Step 5: Reduce to a single digit (unless it's 11, 22, or 33)
    let finalNumber = totalSum
    if (![11, 22, 33].includes(totalSum) && totalSum > 9) {
      finalNumber = sumDigits(totalSum)
      steps.push(`Final reduction: ${totalSum} → ${finalNumber}`)
    }

    setCalculationSteps(steps)
    setLifePathNumber(finalNumber)
  }

  const sumDigits = (num: number): number => {
    // Special case for master numbers
    if (num === 11 || num === 22 || num === 33) {
      return num
    }

    let sum = 0
    while (num > 0 || sum > 9) {
      if (num === 0) {
        num = sum
        sum = 0
      }
      sum += num % 10
      num = Math.floor(num / 10)
    }
    return sum
  }

  const getLifePathData = () => {
    if (lifePathNumber === null) return null
    return lifePathData.find((data) => data.number === lifePathNumber)
  }

  const pathData = getLifePathData()

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/80">
      <Navbar />

      <main className="container mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-bold mb-4">Numerology Insights</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Discover your Life Path Number and what it reveals about your personality, strengths, and life purpose.
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>Life Path Number Calculator</CardTitle>
              <CardDescription>Enter your birthdate to calculate your Life Path Number</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="birthdate">Your Birthdate</Label>
                  <Input
                    id="birthdate"
                    type="date"
                    value={birthdate}
                    onChange={(e) => setBirthdate(e.target.value)}
                    placeholder="YYYY-MM-DD"
                  />
                  {error && <p className="text-sm text-red-500">{error}</p>}
                </div>

                <Button className="w-full" size="lg" onClick={calculateLifePathNumber} disabled={!birthdate}>
                  <CalculatorIcon className="mr-2 h-5 w-5" />
                  Calculate Life Path Number
                </Button>

                {lifePathNumber !== null && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.5 }}
                    className="mt-6"
                  >
                    <div className="text-center mb-6">
                      <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-primary text-primary-foreground text-4xl font-bold mb-2">
                        {lifePathNumber}
                      </div>
                      <h3 className="text-2xl font-bold">Your Life Path Number is {lifePathNumber}</h3>
                    </div>

                    <Tabs defaultValue="meaning">
                      <TabsList className="w-full">
                        <TabsTrigger value="calculation">Calculation</TabsTrigger>
                        <TabsTrigger value="meaning">Meaning</TabsTrigger>
                        <TabsTrigger value="traits">Traits & Challenges</TabsTrigger>
                      </TabsList>

                      <TabsContent value="calculation" className="space-y-4 mt-4">
                        <div className="bg-muted/30 p-4 rounded-lg">
                          <h4 className="font-medium mb-2">How Your Life Path Number Was Calculated:</h4>
                          <ul className="space-y-2 text-sm">
                            {calculationSteps.map((step, index) => (
                              <li key={index} className="text-muted-foreground">
                                {step}
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div className="flex items-start">
                          <InfoIcon className="h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                          <p className="text-sm text-muted-foreground">
                            In numerology, we reduce all numbers to a single digit (1-9) except for Master Numbers 11,
                            22, and 33, which have special significance and are not reduced further.
                          </p>
                        </div>
                      </TabsContent>

                      <TabsContent value="meaning" className="space-y-4 mt-4">
                        {pathData && (
                          <>
                            <h4 className="text-xl font-semibold mb-2">{pathData.title}</h4>
                            <p className="text-muted-foreground mb-4">{pathData.description}</p>

                            <div className="bg-muted/30 p-4 rounded-lg">
                              <h5 className="font-medium mb-2">Life Purpose</h5>
                              <p className="text-sm text-muted-foreground">{pathData.lifePurpose}</p>
                            </div>
                          </>
                        )}
                      </TabsContent>

                      <TabsContent value="traits" className="space-y-4 mt-4">
                        {pathData && (
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="bg-muted/30 p-4 rounded-lg">
                              <h5 className="font-medium mb-2">Positive Traits</h5>
                              <ul className="space-y-1">
                                {pathData.positiveTraits.map((trait, index) => (
                                  <li key={index} className="text-sm text-muted-foreground">
                                    • {trait}
                                  </li>
                                ))}
                              </ul>
                            </div>

                            <div className="bg-muted/30 p-4 rounded-lg">
                              <h5 className="font-medium mb-2">Challenges</h5>
                              <ul className="space-y-1">
                                {pathData.challenges.map((challenge, index) => (
                                  <li key={index} className="text-sm text-muted-foreground">
                                    • {challenge}
                                  </li>
                                ))}
                              </ul>
                            </div>

                            <div className="bg-muted/30 p-4 rounded-lg md:col-span-2">
                              <h5 className="font-medium mb-2">Career Paths</h5>
                              <p className="text-sm text-muted-foreground">{pathData.careerPaths}</p>
                            </div>
                          </div>
                        )}
                      </TabsContent>
                    </Tabs>
                  </motion.div>
                )}
              </div>
            </CardContent>
          </Card>

          <div className="mt-12">
            <h2 className="text-2xl font-bold mb-6 text-center">Understanding Numerology</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>What is Numerology?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    Numerology is the belief in the divine or mystical relationship between numbers and events. It is
                    often associated with the paranormal, alongside astrology and similar divinatory arts.
                  </p>
                  <p className="text-muted-foreground mt-4">
                    The practice of numerology involves calculating various numbers based on your name and birthdate,
                    with each number having specific meanings and influences on different aspects of your life.
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Life Path Number</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">
                    The Life Path Number is the most important number in your numerology chart. It reveals your most
                    fulfilling direction in life and the major lessons you're here to learn.
                  </p>
                  <p className="text-muted-foreground mt-4">
                    Calculated from your birthdate, your Life Path Number represents who you are at your core — your
                    innate traits, abilities, and the challenges you may face throughout your life journey.
                  </p>
                </CardContent>
              </Card>
            </div>

            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Master Numbers</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  In numerology, the numbers 11, 22, and 33 are considered "Master Numbers" with special significance:
                </p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-muted/30 p-4 rounded-lg">
                    <h4 className="font-medium mb-2">Master Number 11</h4>
                    <p className="text-sm text-muted-foreground">
                      The Intuitive. Represents spiritual insight, enlightenment, and intuitive abilities. People with
                      this Life Path are often visionaries with heightened sensitivity.
                    </p>
                  </div>

                  <div className="bg-muted/30 p-4 rounded-lg">
                    <h4 className="font-medium mb-2">Master Number 22</h4>
                    <p className="text-sm text-muted-foreground">
                      The Master Builder. Combines vision with practical action. People with this Life Path have the
                      potential to achieve great things and make a significant impact on the world.
                    </p>
                  </div>

                  <div className="bg-muted/30 p-4 rounded-lg">
                    <h4 className="font-medium mb-2">Master Number 33</h4>
                    <p className="text-sm text-muted-foreground">
                      The Master Teacher. Represents compassion, healing, and selfless service. People with this rare
                      Life Path often dedicate themselves to helping others and raising consciousness.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}

