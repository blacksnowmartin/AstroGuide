"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { zodiacSigns } from "@/lib/zodiac-data"
import { motion } from "framer-motion"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"

export default function ZodiacPage() {
  const [selectedElement, setSelectedElement] = useState("all")

  const filteredSigns =
    selectedElement === "all"
      ? zodiacSigns
      : zodiacSigns.filter((sign) => sign.element.toLowerCase() === selectedElement)

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/80">
      <Navbar />

      <main className="container mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-bold mb-4">Zodiac Sign Details</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Explore the unique characteristics, traits, and insights for each of the twelve zodiac signs.
          </p>
        </motion.div>

        <Tabs defaultValue="all" onValueChange={setSelectedElement} className="mb-8">
          <TabsList className="w-full max-w-md mx-auto">
            <TabsTrigger value="all">All Signs</TabsTrigger>
            <TabsTrigger value="fire">Fire</TabsTrigger>
            <TabsTrigger value="earth">Earth</TabsTrigger>
            <TabsTrigger value="air">Air</TabsTrigger>
            <TabsTrigger value="water">Water</TabsTrigger>
          </TabsList>
        </Tabs>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredSigns.map((sign, index) => (
            <motion.div
              key={sign.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="h-full overflow-hidden zodiac-card">
                <div className={`h-2 ${getElementColor(sign.element)}`}></div>
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <span className="text-3xl mr-3">{sign.symbol}</span>
                    <div>
                      <h2 className="text-2xl font-bold">{sign.name}</h2>
                      <p className="text-muted-foreground">{sign.dates}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">Element</h3>
                      <p>{sign.element}</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">Quality</h3>
                      <p>{sign.quality}</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">Ruling Planet</h3>
                      <p>{sign.rulingPlanet}</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground">Symbol</h3>
                      <p>{sign.symbolName}</p>
                    </div>
                  </div>

                  <div className="mb-4">
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Personality Traits</h3>
                    <div className="flex flex-wrap gap-2">
                      {sign.traits.map((trait, i) => (
                        <span key={i} className="px-2 py-1 bg-muted/30 rounded-md text-sm">
                          {trait}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="mb-4">
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Strengths</h3>
                    <p>{sign.strengths}</p>
                  </div>

                  <div className="mb-4">
                    <h3 className="text-sm font-medium text-muted-foreground mb-1">Weaknesses</h3>
                    <p>{sign.weaknesses}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground mb-1">Lucky Numbers</h3>
                      <p>{sign.luckyNumbers.join(", ")}</p>
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground mb-1">Lucky Colors</h3>
                      <p>{sign.luckyColors.join(", ")}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </main>

      <Footer />
    </div>
  )
}

function getElementColor(element: string) {
  switch (element) {
    case "Fire":
      return "bg-orange-500"
    case "Earth":
      return "bg-green-500"
    case "Air":
      return "bg-blue-400"
    case "Water":
      return "bg-indigo-400"
    default:
      return "bg-primary"
  }
}

