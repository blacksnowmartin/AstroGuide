import "./globals.css";
import type { Metadata } from "next";
import { Inter } from "next/font/google";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { MoonIcon, SunIcon } from "lucide-react";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "AstroGuide - Your Personal Astrology Companion",
  description:
    "Explore daily horoscopes, zodiac compatibility, and numerology insights",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={`${inter.className} min-h-screen bg-gradient-to-b from-background to-background/80`}>
        <nav className="sticky top-0 z-50 w-full bg-background/80 backdrop-blur-md border-b border-border">
          <div className="container mx-auto px-4 py-3 flex justify-between items-center">
            <Link href="/" className="flex items-center space-x-2">
              <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-accent">
                AstroGuide
              </span>
            </Link>
            <div className="hidden md:flex items-center space-x-6">
              <Link
                href="/"
                className="text-foreground/80 hover:text-primary transition-colors"
              >
                Home
              </Link>
              <Link
                href="/horoscope"
                className="text-foreground/80 hover:text-primary transition-colors"
              >
                Daily Horoscope
              </Link>
              <Link
                href="/zodiac"
                className="text-foreground/80 hover:text-primary transition-colors"
              >
                Zodiac Signs
              </Link>
              <Link
                href="/compatibility"
                className="text-foreground/80 hover:text-primary transition-colors"
              >
                Compatibility
              </Link>
              <Link
                href="/numerology"
                className="text-foreground/80 hover:text-primary transition-colors"
              >
                Numerology
              </Link>
            </div>
            <div className="hidden md:flex items-center space-x-4">
              <Button
                variant="ghost"
                size="icon"
                aria-label="Toggle theme"
                className="hover:bg-accent hover:text-accent-foreground h-10 w-10"
              >
                <SunIcon className="h-[1.5rem] w-[1.5rem]" />
              </Button>
              <Button
                variant="outline"
                className="border border-input bg-background hover:bg-accent hover:text-accent-foreground h-10 px-4 py-2"
              >
                Sign In
              </Button>
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2">
                Sign Up
              </Button>
            </div>

            {/* Mobile Navigation */}
            <div className="md:hidden flex items-center">
              <Button
                variant="ghost"
                size="icon"
                aria-label="Toggle theme"
                className="hover:bg-accent hover:text-accent-foreground h-10 w-10 mr-2"
              >
                <SunIcon className="h-[1.5rem] w-[1.5rem]" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                aria-label="Toggle menu"
                className="hover:bg-accent hover:text-accent-foreground h-10 w-10"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <line x1="4" x2="20" y1="12" y2="12" />
                  <line x1="4" x2="20" y1="6" y2="6" />
                  <line x1="4" x2="20" y1="18" y2="18" />
                </svg>
              </Button>
            </div>
          </div>
        </nav>

        {children}

        <footer className="bg-muted/30 border-t border-border">
          <div className="container mx-auto px-4 py-12">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div className="md:col-span-1">
                <Link href="/" className="inline-block mb-4">
                  <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-accent">
                    AstroGuide
                  </span>
                </Link>
                <p className="text-muted-foreground mb-4">
                  Your personal guide to the cosmos, helping you navigate life's
                  journey through astrology.
                </p>
                <div className="flex space-x-4">
                  <Button
                    variant="ghost"
                    size="icon"
                    aria-label="Facebook"
                    className="hover:bg-accent hover:text-accent-foreground h-10 w-10"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
                    </svg>
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    aria-label="Twitter"
                    className="hover:bg-accent hover:text-accent-foreground h-10 w-10"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z" />
                    </svg>
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    aria-label="Instagram"
                    className="hover:bg-accent hover:text-accent-foreground h-10 w-10"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <rect
                        width="20"
                        height="20"
                        x="2"
                        y="2"
                        rx="5"
                        ry="5"
                      />
                      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                      <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
                    </svg>
                  </Button>
                </div>
              </div>
              <div>
                <h3 className="font-semibold text-lg mb-4">Quick Links</h3>
                <ul className="space-y-2">
                  <li>
                    <Link
                      href="/horoscope"
                      className="text-muted-foreground hover:text-primary transition-colors"
                    >
                      Daily Horoscope
                    </Link>
                  </li>
                  <li>
                    <Link
                      href="/zodiac"
                      className="text-muted-foreground hover:text-primary transition-colors"
                    >
                      Zodiac Signs
                    </Link>
                  </li>
                  <li>
                    <Link
                      href="/compatibility"
                      className="text-muted-foreground hover:text-primary transition-colors"
                    >
                      Compatibility Check
                    </Link>
                  </li>
                  <li>
                    <Link
                      href="/numerology"
                      className="text-muted-foreground hover:text-primary transition-colors"
                    >
                      Numerology Insights
                    </Link>
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-lg mb-4">Resources</h3>
                <ul className="space-y-2">
                  <li>
                    <Link
                      href="/blog"
                      className="text-muted-foreground hover:text-primary transition-colors"
                    >
                      Astrology Blog
                    </Link>
                  </li>
                  <li>
                    <Link
                      href="/faq"
                      className="text-muted-foreground hover:text-primary transition-colors"
                    >
                      FAQ
                    </Link>
                  </li>
                  <li>
                    <Link
                      href="/about"
                      className="text-muted-foreground hover:text-primary transition-colors"
                    >
                      About Us
                    </Link>
                  </li>
                  <li>
                    <Link
                      href="/contact"
                      className="text-muted-foreground hover:text-primary transition-colors"
                    >
                      Contact
                    </Link>
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-lg mb-4">Subscribe</h3>
                <p className="text-muted-foreground mb-4">
                  Get your weekly horoscope and cosmic updates delivered to your
                  inbox.
                </p>
                <div className="flex space-x-2">
                  <Button className="bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="mr-2"
                    >
                      <rect
                        width="20"
                        height="16"
                        x="2"
                        y="4"
                        rx="2"
                      />
                      <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
                    </svg>
                    Subscribe
                  </Button>
                </div>
              </div>
            </div>
            <div className="border-t border-border mt-8 pt-8 text-center text-muted-foreground">
              <p>© 2025 AstroGuide. All rights reserved.</p>
            </div>
          </div>
        </footer>
      </body>
    </html>
  );
}
