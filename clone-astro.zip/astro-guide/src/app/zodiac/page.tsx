'use client';

import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState } from "react";

const zodiacSigns = [
  {
    name: "Aries",
    dates: "March 21 - April 19",
    element: "Fire",
    quality: "Cardinal",
    rulingPlanet: "Mars",
    symbol: "The Ram",
    personalityTraits: ["Courageous", "Determined", "Confident", "Enthusiastic", "Passionate"],
    strengths: "Aries are natural leaders with boundless energy and enthusiasm. They're courageous, determined, and confident in pursuing their goals.",
    weaknesses: "Can be impatient, short-tempered, and impulsive. May act before thinking and struggle with finishing what they start.",
    luckyNumbers: [1, 8, 17],
    luckyColors: ["Red", "Orange", "Yellow"]
  },
  {
    name: "Taurus",
    dates: "April 20 - May 20",
    element: "Earth",
    quality: "Fixed",
    rulingPlanet: "Venus",
    symbol: "The Bull",
    personalityTraits: ["Reliable", "Patient", "Practical", "Devoted", "Responsible"],
    strengths: "Taurus individuals are reliable, patient, and practical. They have a strong sense of determination and work steadily toward their goals.",
    weaknesses: "Can be stubborn, possessive, and uncompromising. May resist change and become too fixed in their ways.",
    luckyNumbers: [2, 6, 9],
    luckyColors: ["Green", "Pink", "Blue"]
  },
  {
    name: "Gemini",
    dates: "May 21 - June 20",
    element: "Air",
    quality: "Mutable",
    rulingPlanet: "Mercury",
    symbol: "The Twins",
    personalityTraits: ["Gentle", "Affectionate", "Curious", "Adaptable", "Quick-witted"],
    strengths: "Geminis are adaptable, outgoing, and intellectually curious. They're excellent communicators with a quick wit and youthful enthusiasm.",
    weaknesses: "Can be nervous, inconsistent, and indecisive. May try to do too many things at once and struggle with focus.",
    luckyNumbers: [3, 5, 8],
    luckyColors: ["Yellow", "Blue", "Green"]
  },
  {
    name: "Cancer",
    dates: "June 21 - July 22",
    element: "Water",
    quality: "Cardinal",
    rulingPlanet: "Moon",
    symbol: "The Crab",
    personalityTraits: ["Tenacious", "Highly Imaginative", "Loyal", "Emotional", "Sympathetic"],
    strengths: "Cancers are deeply intuitive, emotional, and caring. They're fiercely loyal to family and friends, with a strong protective instinct.",
    weaknesses: "Can be moody, pessimistic, and suspicious. May be overly sensitive and reluctant to directly confront problems.",
    luckyNumbers: [2, 7, 11],
    luckyColors: ["White", "Silver", "Blue"]
  },
  {
    name: "Leo",
    dates: "July 23 - August 22",
    element: "Fire",
    quality: "Fixed",
    rulingPlanet: "Sun",
    symbol: "The Lion",
    personalityTraits: ["Creative", "Passionate", "Generous", "Warm-hearted", "Cheerful"],
    strengths: "Leos are creative, passionate, and generous. They have natural leadership abilities and a flair for the dramatic that draws others to them.",
    weaknesses: "Can be arrogant, stubborn, and self-centered. May have a tendency to be domineering and inflexible.",
    luckyNumbers: [1, 5, 9],
    luckyColors: ["Gold", "Orange", "Red"]
  },
  {
    name: "Virgo",
    dates: "August 23 - September 22",
    element: "Earth",
    quality: "Mutable",
    rulingPlanet: "Mercury",
    symbol: "The Maiden",
    personalityTraits: ["Loyal", "Analytical", "Kind", "Hardworking", "Practical"],
    strengths: "Virgos are analytical, practical, and attentive to detail. They're hardworking, reliable, and have a deep sense of humanity.",
    weaknesses: "Can be overly critical, worry too much, and be excessively concerned with cleanliness and order. May be too perfectionistic.",
    luckyNumbers: [3, 6, 7],
    luckyColors: ["Green", "Brown", "Cream"]
  },
  {
    name: "Libra",
    dates: "September 23 - October 22",
    element: "Air",
    quality: "Cardinal",
    rulingPlanet: "Venus",
    symbol: "The Scales",
    personalityTraits: ["Diplomatic", "Fair-minded", "Social", "Cooperative", "Gracious"],
    strengths: "Libras are cooperative, diplomatic, and fair-minded. They value harmony and balance, with a strong sense of justice and beauty.",
    weaknesses: "Can be indecisive, avoidant of confrontation, and self-pitying. May carry grudges and be too concerned with pleasing others.",
    luckyNumbers: [4, 6, 13],
    luckyColors: ["Pink", "Blue", "White"]
  },
  {
    name: "Scorpio",
    dates: "October 23 - November 21",
    element: "Water",
    quality: "Fixed",
    rulingPlanet: "Pluto, Mars",
    symbol: "The Scorpion",
    personalityTraits: ["Resourceful", "Brave", "Passionate", "Stubborn", "Intense"],
    strengths: "Scorpios are resourceful, passionate, and brave. They have powerful emotional depths, strong willpower, and are fiercely loyal to those they trust.",
    weaknesses: "Can be distrusting, jealous, secretive, and resentful. May be too controlling and struggle with forgiveness.",
    luckyNumbers: [8, 11, 18],
    luckyColors: ["Black", "Red", "Purple"]
  },
  {
    name: "Sagittarius",
    dates: "November 22 - December 21",
    element: "Fire",
    quality: "Mutable",
    rulingPlanet: "Jupiter",
    symbol: "The Archer",
    personalityTraits: ["Generous", "Idealistic", "Humorous", "Adventurous", "Enthusiastic"],
    strengths: "Sagittarians are generous, idealistic, and have a great sense of humor. They're adventurous, enthusiastic, and have a love for freedom and exploration.",
    weaknesses: "Can be tactless, restless, and overconfident. May make promises they can't keep and be too blunt with others.",
    luckyNumbers: [3, 7, 9],
    luckyColors: ["Blue", "Purple", "Red"]
  },
  {
    name: "Capricorn",
    dates: "December 22 - January 19",
    element: "Earth",
    quality: "Cardinal",
    rulingPlanet: "Saturn",
    symbol: "The Goat",
    personalityTraits: ["Responsible", "Disciplined", "Self-controlled", "Good managers", "Practical"],
    strengths: "Capricorns are responsible, disciplined, and have excellent self-control. They're good managers with practical wisdom and a strong sense of tradition.",
    weaknesses: "Can be know-it-alls, unforgiving, condescending, and expecting the worst. May be too focused on work and status.",
    luckyNumbers: [4, 8, 13],
    luckyColors: ["Brown", "Black", "Dark Green"]
  },
  {
    name: "Aquarius",
    dates: "January 20 - February 18",
    element: "Air",
    quality: "Fixed",
    rulingPlanet: "Uranus, Saturn",
    symbol: "The Water Bearer",
    personalityTraits: ["Progressive", "Original", "Independent", "Humanitarian", "Inventive"],
    strengths: "Aquarians are progressive, original, and independent. They're humanitarian with strong ideals and an inventive, analytical mind.",
    weaknesses: "Can be temperamental, uncompromising, aloof, and emotionally detached. May run from emotional expression.",
    luckyNumbers: [4, 7, 11],
    luckyColors: ["Blue", "Turquoise", "Silver"]
  },
  {
    name: "Pisces",
    dates: "February 19 - March 20",
    element: "Water",
    quality: "Mutable",
    rulingPlanet: "Neptune, Jupiter",
    symbol: "The Fish",
    personalityTraits: ["Compassionate", "Artistic", "Intuitive", "Gentle", "Wise"],
    strengths: "Pisceans are compassionate, artistic, and intuitive. They're gentle, wise, and have a strong connection to music and artistic expression.",
    weaknesses: "Can be fearful, overly trusting, sad, desire to escape reality, and self-pitying. May be prone to victimhood.",
    luckyNumbers: [3, 9, 12],
    luckyColors: ["Sea Green", "Lavender", "Purple"]
  }
];

export default function ZodiacSigns() {
  const [activeTab, setActiveTab] = useState("All Signs");

  const filterSigns = (filter: string) => {
    if (filter === "All Signs") return zodiacSigns;
    return zodiacSigns.filter(sign => sign.element === filter);
  };

  return (
    <main className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Zodiac Sign Details</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Explore the unique characteristics, traits, and insights for each of the
          twelve zodiac signs.
        </p>
      </div>

      <Tabs defaultValue="All Signs" className="mb-8">
        <TabsList className="flex justify-center mb-8">
          <TabsTrigger value="All Signs" onClick={() => setActiveTab("All Signs")}>All Signs</TabsTrigger>
          <TabsTrigger value="Fire" onClick={() => setActiveTab("Fire")}>Fire</TabsTrigger>
          <TabsTrigger value="Earth" onClick={() => setActiveTab("Earth")}>Earth</TabsTrigger>
          <TabsTrigger value="Air" onClick={() => setActiveTab("Air")}>Air</TabsTrigger>
          <TabsTrigger value="Water" onClick={() => setActiveTab("Water")}>Water</TabsTrigger>
        </TabsList>

        {["All Signs", "Fire", "Earth", "Air", "Water"].map(element => (
          <TabsContent key={element} value={element}>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filterSigns(element).map((sign) => (
                <Card key={sign.name} className="p-6 h-full border-t-4 border-t-primary">
                  <div className="mb-4">
                    <h2 className="text-2xl font-bold">{sign.name}</h2>
                    <p className="text-muted-foreground text-sm">{sign.dates}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <h3 className="text-sm text-muted-foreground mb-1">Element</h3>
                      <p className="font-medium">{sign.element}</p>
                    </div>
                    <div>
                      <h3 className="text-sm text-muted-foreground mb-1">Quality</h3>
                      <p className="font-medium">{sign.quality}</p>
                    </div>
                    <div>
                      <h3 className="text-sm text-muted-foreground mb-1">Ruling Planet</h3>
                      <p className="font-medium">{sign.rulingPlanet}</p>
                    </div>
                    <div>
                      <h3 className="text-sm text-muted-foreground mb-1">Symbol</h3>
                      <p className="font-medium">{sign.symbol}</p>
                    </div>
                  </div>

                  <div className="mb-4">
                    <h3 className="text-sm text-muted-foreground mb-2">Personality Traits</h3>
                    <div className="flex flex-wrap gap-2">
                      {sign.personalityTraits.map((trait, index) => (
                        <span key={index} className="px-2 py-1 bg-muted/50 rounded-md text-sm">
                          {trait}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="mb-4">
                    <h3 className="text-sm text-muted-foreground mb-1">Strengths</h3>
                    <p className="text-sm">{sign.strengths}</p>
                  </div>

                  <div className="mb-4">
                    <h3 className="text-sm text-muted-foreground mb-1">Weaknesses</h3>
                    <p className="text-sm">{sign.weaknesses}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h3 className="text-sm text-muted-foreground mb-1">Lucky Numbers</h3>
                      <p>{sign.luckyNumbers.join(", ")}</p>
                    </div>
                    <div>
                      <h3 className="text-sm text-muted-foreground mb-1">Lucky Colors</h3>
                      <p>{sign.luckyColors.join(", ")}</p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </main>
  );
}
