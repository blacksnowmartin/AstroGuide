'use client';

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import { X } from "lucide-react";

export default function Home() {
  const [showTip, setShowTip] = useState(true);
  const [animateIn, setAnimateIn] = useState(false);

  useEffect(() => {
    setAnimateIn(true);
  }, []);

  return (
    <main>
      <div className="relative">
        <section className="relative z-10 py-20 px-4">
          <div className="container mx-auto text-center">
            <div
              style={{
                opacity: animateIn ? 1 : 0,
                transform: animateIn ? "none" : "translateY(20px)",
                transition: "opacity 0.5s ease, transform 0.5s ease",
              }}
            >
              <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-primary via-accent to-secondary">
                Discover Your Cosmic Path
              </h1>
              <p className="text-xl md:text-2xl text-foreground/80 max-w-3xl mx-auto mb-10">
                Explore daily horoscopes, zodiac compatibility, and numerology
                insights tailored just for you.
              </p>
            </div>
            <div
              className="flex flex-wrap justify-center gap-4 mb-16"
              style={{
                opacity: animateIn ? 1 : 0,
                transition: "opacity 0.5s ease 0.2s",
              }}
            >
              <Link href="/horoscope">
                <Button variant="default" size="lg" className="h-11 rounded-md px-8">
                  Get Your Daily Horoscope
                </Button>
              </Link>
              <Link href="/zodiac">
                <Button variant="outline" size="lg" className="h-11 rounded-md px-8">
                  Explore Zodiac Signs
                </Button>
              </Link>
            </div>

            {showTip && (
              <div
                className="fixed bottom-4 right-4 z-50 max-w-md"
                style={{
                  opacity: animateIn ? 1 : 0,
                  transform: animateIn ? "none" : "translateY(20px)",
                  transition: "opacity 0.5s ease 0.4s, transform 0.5s ease 0.4s",
                }}
              >
                <Card className="border-primary">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-semibold text-lg">✨ Daily Astrology Tip</h3>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 w-6 p-0"
                        onClick={() => setShowTip(false)}
                      >
                        <X size={16} />
                      </Button>
                    </div>
                    <p className="text-muted-foreground">
                      Take a moment today to meditate and connect with your inner
                      self.
                    </p>
                  </CardContent>
                </Card>
              </div>
            )}

            <div
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-16"
              style={{
                opacity: animateIn ? 1 : 0,
                transform: animateIn ? "none" : "translateY(20px)",
                transition: "opacity 0.5s ease 0.6s, transform 0.5s ease 0.6s",
              }}
            >
              <Link href="/horoscope">
                <Card className="p-6 h-full flex flex-col items-center text-center transition-all duration-300 hover:border-primary zodiac-card">
                  <div className="mb-4 p-3 rounded-full bg-muted flex items-center justify-center">
                    <Image
                      src="https://ext.same-assets.com/1639405841/4061061103.svg"
                      alt=""
                      width={40}
                      height={40}
                    />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Daily Horoscope</h3>
                  <p className="text-muted-foreground">
                    Get personalized daily insights based on your zodiac sign.
                  </p>
                </Card>
              </Link>

              <Link href="/zodiac">
                <Card className="p-6 h-full flex flex-col items-center text-center transition-all duration-300 hover:border-primary zodiac-card">
                  <div className="mb-4 p-3 rounded-full bg-muted flex items-center justify-center">
                    <Image
                      src="https://ext.same-assets.com/1639405841/2320907649.svg"
                      alt=""
                      width={40}
                      height={40}
                    />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Zodiac Signs</h3>
                  <p className="text-muted-foreground">
                    Explore detailed profiles of all twelve zodiac signs.
                  </p>
                </Card>
              </Link>

              <Link href="/compatibility">
                <Card className="p-6 h-full flex flex-col items-center text-center transition-all duration-300 hover:border-primary zodiac-card">
                  <div className="mb-4 p-3 rounded-full bg-muted flex items-center justify-center">
                    <Image
                      src="https://ext.same-assets.com/1639405841/1998606599.svg"
                      alt=""
                      width={40}
                      height={40}
                    />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Compatibility</h3>
                  <p className="text-muted-foreground">
                    Check your romantic and friendship compatibility.
                  </p>
                </Card>
              </Link>

              <Link href="/numerology">
                <Card className="p-6 h-full flex flex-col items-center text-center transition-all duration-300 hover:border-primary zodiac-card">
                  <div className="mb-4 p-3 rounded-full bg-muted flex items-center justify-center">
                    <Image
                      src="https://ext.same-assets.com/1639405841/1367661487.svg"
                      alt=""
                      width={40}
                      height={40}
                    />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">Numerology</h3>
                  <p className="text-muted-foreground">
                    Discover your life path number and its meaning.
                  </p>
                </Card>
              </Link>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}
