'use client';

import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Calculator } from "lucide-react";

// Life Path Number information
const lifePathInfo = {
  1: {
    title: "The Leader",
    description: "Independent, ambitious, and determined. Life Path 1 individuals are natural leaders and innovators with strong drive and determination. They're self-reliant, original, and have excellent executive abilities.",
    strengths: "Leadership, innovation, independence, determination, ambition",
    challenges: "May be overly dominant, impatient, or too focused on self-achievement"
  },
  2: {
    title: "The Mediator",
    description: "Cooperative, diplomatic, and intuitive. Life Path 2 individuals excel in partnerships and are natural peacemakers. They're sensitive, patient, and have excellent diplomatic skills.",
    strengths: "Cooperation, sensitivity, diplomacy, patience, attention to detail",
    challenges: "May be overly sensitive, indecisive, or dependent on others"
  },
  3: {
    title: "The Expressive Creative",
    description: "Creative, social, and optimistic. Life Path 3 individuals are natural entertainers with excellent communication skills. They're enthusiastic, inspiring, and bring joy to others.",
    strengths: "Creativity, self-expression, joy, optimism, inspiration",
    challenges: "May scatter energies, lack focus, or avoid emotional depth"
  },
  4: {
    title: "The Builder",
    description: "Practical, reliable, and hardworking. Life Path 4 individuals create solid foundations and value stability. They're diligent, methodical, and extremely trustworthy.",
    strengths: "Practicality, organization, determination, reliability, efficiency",
    challenges: "May be too rigid, stubborn, or resistant to change"
  },
  5: {
    title: "The Freedom Seeker",
    description: "Versatile, adventurous, and progressive. Life Path 5 individuals embrace change and seek freedom. They're adaptable, curious, and bring excitement to life.",
    strengths: "Adaptability, versatility, resourcefulness, curiosity, enthusiasm",
    challenges: "May be restless, erratic, or have difficulty with commitment"
  },
  6: {
    title: "The Nurturer",
    description: "Responsible, compassionate, and harmonious. Life Path 6 individuals are natural caregivers with a strong sense of duty. They're loving, protective, and create balance.",
    strengths: "Responsibility, compassion, harmony, service, nurturing",
    challenges: "May be self-sacrificing, meddling, or perfectionistic"
  },
  7: {
    title: "The Seeker",
    description: "Analytical, spiritual, and introspective. Life Path 7 individuals pursue knowledge and spiritual truths. They're insightful, intellectual, and often possess psychic abilities.",
    strengths: "Analysis, wisdom, intuition, independence, specialization",
    challenges: "May be withdrawn, secretive, or overly critical"
  },
  8: {
    title: "The Powerhouse",
    description: "Ambitious, successful, and authoritative. Life Path 8 individuals excel in business and leadership roles. They understand power and can manifest material success.",
    strengths: "Ambition, organization, practicality, leadership, achievement",
    challenges: "May be workaholic, materialistic, or controlling"
  },
  9: {
    title: "The Humanitarian",
    description: "Compassionate, inspiring, and idealistic. Life Path 9 individuals serve humanity and pursue universal wisdom. They're tolerant, giving, and spiritually oriented.",
    strengths: "Compassion, idealism, philanthropy, creativity, wisdom",
    challenges: "May be overly idealistic, emotionally distant, or martyrlike"
  },
  11: {
    title: "The Intuitive",
    description: "Inspirational, intuitive, and visionary. Life Path 11 individuals have heightened spiritual awareness and intuition. They're idealistic, inspirational, and can bring illumination to others.",
    strengths: "Intuition, inspiration, idealism, sensitivity, spiritual insight",
    challenges: "May experience nervous tension, impracticality, or emotional extremes"
  },
  22: {
    title: "The Master Builder",
    description: "Practical visionary, powerful manifestor, and achiever. Life Path 22 individuals can turn ambitious dreams into reality. They have exceptional leadership and manifestation abilities.",
    strengths: "Practicality, vision, leadership, achievement, manifestation abilities",
    challenges: "May struggle with overwhelming responsibility or unfulfilled potential"
  },
  33: {
    title: "The Master Teacher",
    description: "Nurturing, spiritual guide, and compassionate healer. Life Path 33 individuals elevate consciousness through loving service. They're selfless teachers with powerful healing abilities.",
    strengths: "Compassion, inspiration, healing, nurturing, selfless service",
    challenges: "May experience extreme self-sacrifice or difficulty with boundaries"
  }
};

// Calculate Life Path Number from birthdate
const calculateLifePathNumber = (birthdate: string): number | null => {
  if (!birthdate) return null;

  // Extract numbers from date format (yyyy-mm-dd)
  const parts = birthdate.split('-');
  if (parts.length !== 3) return null;

  const year = parts[0];
  const month = parts[1];
  const day = parts[2];

  // Sum all digits
  const yearSum = sumDigits(year);
  const monthSum = sumDigits(month);
  const daySum = sumDigits(day);

  // Sum year, month, and day values
  let sum = yearSum + monthSum + daySum;

  // Reduce to single digit or master number
  while (sum > 9 && sum !== 11 && sum !== 22 && sum !== 33) {
    sum = sumDigits(sum.toString());
  }

  return sum;
};

// Helper function to sum digits of a number
const sumDigits = (numStr: string): number => {
  return numStr.split('').reduce((sum, digit) => sum + parseInt(digit, 10), 0);
};

export default function Numerology() {
  const [birthdate, setBirthdate] = useState("");
  const [lifePathNumber, setLifePathNumber] = useState<number | null>(null);

  const handleCalculate = () => {
    const result = calculateLifePathNumber(birthdate);
    setLifePathNumber(result);
  };

  return (
    <main className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Numerology Insights</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Discover your Life Path Number and what it reveals about your
          personality, strengths, and life purpose.
        </p>
      </div>

      <div className="max-w-4xl mx-auto">
        <Card>
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold mb-2">Life Path Number Calculator</h2>
            <p className="text-sm text-muted-foreground mb-6">
              Enter your birthdate to calculate your Life Path Number
            </p>

            <div className="space-y-6">
              <div className="space-y-2">
                <label htmlFor="birthdate" className="text-sm font-medium">Your Birthdate</label>
                <Input
                  id="birthdate"
                  type="date"
                  value={birthdate}
                  onChange={(e) => setBirthdate(e.target.value)}
                />
              </div>

              <Button
                className="w-full"
                onClick={handleCalculate}
                disabled={!birthdate}
              >
                <Calculator className="mr-2 h-4 w-4" /> Calculate Life Path Number
              </Button>

              {lifePathNumber && lifePathInfo[lifePathNumber] && (
                <div className="mt-6 p-6 border rounded-lg">
                  <div className="text-center mb-4">
                    <div className="text-2xl font-bold">Your Life Path Number</div>
                    <div className="text-4xl font-bold text-primary mt-2">{lifePathNumber}</div>
                    <div className="text-lg font-semibold text-muted-foreground mt-1">
                      {lifePathInfo[lifePathNumber].title}
                    </div>
                  </div>

                  <div className="space-y-4 mt-6">
                    <div>
                      <h3 className="font-semibold mb-2">What This Number Means</h3>
                      <p className="text-muted-foreground">
                        {lifePathInfo[lifePathNumber].description}
                      </p>
                    </div>

                    <div>
                      <h3 className="font-semibold mb-2">Your Strengths</h3>
                      <p className="text-muted-foreground">
                        {lifePathInfo[lifePathNumber].strengths}
                      </p>
                    </div>

                    <div>
                      <h3 className="font-semibold mb-2">Your Challenges</h3>
                      <p className="text-muted-foreground">
                        {lifePathInfo[lifePathNumber].challenges}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-6 text-center">Understanding Numerology</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-2xl font-semibold mb-4">What is Numerology?</h3>
                <p className="text-muted-foreground">
                  Numerology is the belief in the divine or mystical relationship
                  between numbers and events. It is often associated with the
                  paranormal, alongside astrology and similar divinatory arts.
                </p>
                <p className="text-muted-foreground mt-4">
                  The practice of numerology involves calculating various numbers
                  based on your name and birthdate, with each number having specific
                  meanings and influences on different aspects of your life.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <h3 className="text-2xl font-semibold mb-4">Life Path Number</h3>
                <p className="text-muted-foreground">
                  The Life Path Number is the most important number in your
                  numerology chart. It reveals your most fulfilling direction in
                  life and the major lessons you're here to learn.
                </p>
                <p className="text-muted-foreground mt-4">
                  Calculated from your birthdate, your Life Path Number represents
                  who you are at your core — your innate traits, abilities, and the
                  challenges you may face throughout your life journey.
                </p>
              </CardContent>
            </Card>
          </div>

          <Card className="mt-6">
            <CardContent className="p-6">
              <h3 className="text-2xl font-semibold mb-4">Master Numbers</h3>
              <p className="text-muted-foreground mb-4">
                In numerology, the numbers 11, 22, and 33 are considered "Master
                Numbers" with special significance:
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-muted/30 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Master Number 11</h4>
                  <p className="text-sm text-muted-foreground">
                    The Intuitive. Represents spiritual insight, enlightenment, and
                    intuitive abilities. People with this Life Path are often
                    visionaries with heightened sensitivity.
                  </p>
                </div>
                <div className="bg-muted/30 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Master Number 22</h4>
                  <p className="text-sm text-muted-foreground">
                    The Master Builder. Combines vision with practical action.
                    People with this Life Path have the potential to achieve great
                    things and make a significant impact on the world.
                  </p>
                </div>
                <div className="bg-muted/30 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Master Number 33</h4>
                  <p className="text-sm text-muted-foreground">
                    The Master Teacher. Represents compassion, healing, and selfless
                    service. People with this rare Life Path often dedicate
                    themselves to helping others and raising consciousness.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </main>
  );
}
