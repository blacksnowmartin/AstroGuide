'use client';

import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Heart } from "lucide-react";

const zodiacSigns = [
  "Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo",
  "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"
];

const compatibilityData = {
  elements: {
    Fire: ["Aries", "Leo", "Sagittarius"],
    Earth: ["Taurus", "Virgo", "Capricorn"],
    Air: ["Gemini", "Libra", "Aquarius"],
    Water: ["Cancer", "Scorpio", "Pisces"]
  },
  qualities: {
    Cardinal: ["Aries", "Cancer", "Libra", "Capricorn"],
    Fixed: ["Taurus", "Leo", "Scorpio", "Aquarius"],
    Mutable: ["Gemini", "Virgo", "Sagittarius", "Pisces"]
  }
};

const compatibilityPairings = {
  "Aries-Aries": { score: 70, description: "Dynamic but potentially combative. Two Aries together create a passionate and energetic relationship, but may struggle with power dynamics and impulsiveness." },
  "Aries-Taurus": { score: 45, description: "Challenging match with differing approaches. Aries's impulsivity clashes with Taurus's methodical nature, but they can learn persistence and spontaneity from each other." },
  "Aries-Gemini": { score: 85, description: "Exciting and stimulating partnership. Both enjoy variety and mental stimulation, creating a dynamic relationship full of adventure and communication." },
  "Aries-Cancer": { score: 50, description: "Contrasting emotional styles. Aries's directness may overwhelm sensitive Cancer, but they can balance each other's approaches to feelings and security." },
  "Aries-Leo": { score: 90, description: "Passionate and vibrant match. These fire signs create a relationship filled with enthusiasm, creativity, and mutual admiration." },
  "Aries-Virgo": { score: 40, description: "Opposite approaches to life. Aries's spontaneity conflicts with Virgo's careful planning, but they can teach each other valuable perspectives." },
  "Aries-Libra": { score: 75, description: "Complementary opposites. This pairing offers balance, with Aries providing initiative and Libra contributing harmony and fairness." },
  "Aries-Scorpio": { score: 65, description: "Intense and passionate connection. Both are assertive and determined, creating a powerful but potentially volatile relationship." },
  "Aries-Sagittarius": { score: 95, description: "Exceptional fire sign harmony. These two share a love of adventure, optimism, and independence, creating an exciting and supportive bond." },
  "Aries-Capricorn": { score: 35, description: "Challenging blend of styles. Aries's impulsiveness contrasts with Capricorn's caution, but they can teach each other valuable approaches to goals." },
  "Aries-Aquarius": { score: 80, description: "Innovative and exciting match. Both value independence and new ideas, creating a forward-thinking and stimulating partnership." },
  "Aries-Pisces": { score: 55, description: "Contrasting but potentially balancing. Aries's assertiveness can guide dreamy Pisces, while Pisces can help Aries develop emotional awareness." },
  // Add other sign combinations here
};

// Helper function to get compatibility data
const getCompatibility = (sign1: string, sign2: string) => {
  // Sort alphabetically to match our data structure
  const pair = [sign1, sign2].sort().join("-");
  // Return placeholder if not found
  return compatibilityPairings[pair] || { score: 50, description: "Compatibility data not available." };
};

export default function CompatibilityCheck() {
  const [yourSign, setYourSign] = useState("");
  const [theirSign, setTheirSign] = useState("");
  const [compatibility, setCompatibility] = useState<null | { score: number; description: string }>(null);

  const checkCompatibility = () => {
    if (yourSign && theirSign) {
      // Sort the signs alphabetically to match our compatibility data keys
      const pair = [yourSign, theirSign].sort().join("-");
      const result = compatibilityPairings[pair] || {
        score: 50,
        description: "This combination requires further exploration. Elements and qualities suggest a moderate compatibility."
      };
      setCompatibility(result);
    }
  };

  return (
    <main className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Zodiac Compatibility</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Discover how compatible you are with your partner, friend, or
          colleague based on your zodiac signs.
        </p>
      </div>

      <div className="max-w-4xl mx-auto">
        <Card>
          <CardContent className="p-6">
            <h2 className="text-2xl font-semibold mb-2">Compatibility Check</h2>
            <p className="text-sm text-muted-foreground mb-6">
              Select two zodiac signs to check their compatibility
            </p>

            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Your Zodiac Sign</label>
                  <Select value={yourSign} onValueChange={setYourSign}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select your sign" />
                    </SelectTrigger>
                    <SelectContent>
                      {zodiacSigns.map((sign) => (
                        <SelectItem key={sign} value={sign}>
                          {sign}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Their Zodiac Sign</label>
                  <Select value={theirSign} onValueChange={setTheirSign}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select their sign" />
                    </SelectTrigger>
                    <SelectContent>
                      {zodiacSigns.map((sign) => (
                        <SelectItem key={sign} value={sign}>
                          {sign}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button
                className="w-full"
                onClick={checkCompatibility}
                disabled={!yourSign || !theirSign}
              >
                <Heart className="mr-2 h-4 w-4" /> Check Compatibility
              </Button>

              {compatibility && (
                <div className="mt-6 p-4 border rounded-lg">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-4">
                      <div className="text-xl font-semibold">{yourSign}</div>
                      <div className="text-muted-foreground">+</div>
                      <div className="text-xl font-semibold">{theirSign}</div>
                    </div>
                    <div className="text-xl font-bold">{compatibility.score}%</div>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">Compatibility Analysis</h3>
                    <p className="text-muted-foreground">{compatibility.description}</p>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <div className="mt-12">
          <h2 className="text-2xl font-bold mb-6 text-center">Understanding Zodiac Compatibility</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-2xl font-semibold mb-4">Elements & Compatibility</h3>
                <p className="text-muted-foreground mb-4">
                  Zodiac signs are grouped into four elements, which play a significant
                  role in determining compatibility:
                </p>
                <ul className="space-y-2">
                  <li className="flex items-center">
                    <span className="w-3 h-3 rounded-full bg-orange-500 mr-2"></span>
                    <span className="font-medium">Fire Signs</span>
                    <span className="text-muted-foreground ml-2">(Aries, Leo, Sagittarius)</span>
                  </li>
                  <li className="flex items-center">
                    <span className="w-3 h-3 rounded-full bg-green-500 mr-2"></span>
                    <span className="font-medium">Earth Signs</span>
                    <span className="text-muted-foreground ml-2">(Taurus, Virgo, Capricorn)</span>
                  </li>
                  <li className="flex items-center">
                    <span className="w-3 h-3 rounded-full bg-yellow-300 mr-2"></span>
                    <span className="font-medium">Air Signs</span>
                    <span className="text-muted-foreground ml-2">(Gemini, Libra, Aquarius)</span>
                  </li>
                  <li className="flex items-center">
                    <span className="w-3 h-3 rounded-full bg-blue-500 mr-2"></span>
                    <span className="font-medium">Water Signs</span>
                    <span className="text-muted-foreground ml-2">(Cancer, Scorpio, Pisces)</span>
                  </li>
                </ul>
                <p className="mt-4 text-muted-foreground">
                  Generally, signs of the same element tend to be compatible, as do
                  complementary elements: Fire with Air, and Earth with Water.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <h3 className="text-2xl font-semibold mb-4">Qualities & Compatibility</h3>
                <p className="text-muted-foreground mb-4">
                  Each zodiac sign also belongs to one of three qualities (or
                  modalities), which influence how they interact:
                </p>
                <ul className="space-y-2">
                  <li>
                    <span className="font-medium">Cardinal Signs</span>
                    <span className="text-muted-foreground ml-2">(Aries, Cancer, Libra, Capricorn)</span>
                    <p className="text-sm text-muted-foreground mt-1">
                      Initiators who like to lead and start new things.
                    </p>
                  </li>
                  <li>
                    <span className="font-medium">Fixed Signs</span>
                    <span className="text-muted-foreground ml-2">(Taurus, Leo, Scorpio, Aquarius)</span>
                    <p className="text-sm text-muted-foreground mt-1">
                      Stable and persistent, they maintain what's already established.
                    </p>
                  </li>
                  <li>
                    <span className="font-medium">Mutable Signs</span>
                    <span className="text-muted-foreground ml-2">(Gemini, Virgo, Sagittarius, Pisces)</span>
                    <p className="text-sm text-muted-foreground mt-1">
                      Adaptable and flexible, they're comfortable with change.
                    </p>
                  </li>
                </ul>
                <p className="mt-4 text-muted-foreground">
                  Signs of the same quality may face challenges as they share similar
                  approaches, while different qualities can complement each other.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </main>
  );
}
