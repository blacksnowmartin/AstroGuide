'use client';

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RefreshCw } from "lucide-react";

const zodiacSigns = [
  {
    name: "Aries",
    dates: "March 21 - April 19",
    horoscope: {
      general: "Today brings a surge of energy that propels you toward your goals. Your natural leadership abilities are heightened, making this an excellent day to take charge of projects or inspire others. Be mindful of impatience; not everyone moves at your pace. A surprising conversation could open new doors.",
      love: "Your passionate nature is especially magnetic today. If you're in a relationship, your partner appreciates your directness and enthusiasm. Single Aries might find themselves attracted to someone who challenges them intellectually.",
      career: "Your competitive spirit serves you well in the workplace today. You're likely to impress superiors with your initiative and bold ideas. Consider taking the lead on a new project that showcases your strengths.",
      health: "Channel your abundant energy into physical activity to maintain balance. A high-intensity workout would be particularly satisfying today. Pay attention to your head and face area, which are ruled by Aries."
    },
    luckyNumber: 9,
    luckyColor: "Red",
    mood: "Energetic",
    compatibility: "Libra"
  },
  {
    name: "Taurus",
    dates: "April 20 - May 20",
    horoscope: {
      general: "Stability and comfort are your focus today. You may feel a strong desire to create beauty in your surroundings or enjoy sensory pleasures. Your practical nature helps you make wise decisions about resources. Take time to appreciate the simple things that bring you joy.",
      love: "Your romantic relationships benefit from your steady and reliable nature today. Partners feel secure in your unwavering affection. Single Taurus might attract someone who values your dependability and warm heart.",
      career: "Persistence pays off in your professional life today. A methodical approach to tasks brings excellent results. Your colleagues appreciate your reliability and practical solutions to problems.",
      health: "Nourishing foods and gentle exercise support your wellbeing today. Consider activities that engage your senses, like aromatherapy or a walk in nature. Pay attention to your throat area, which Taurus rules."
    },
    luckyNumber: 6,
    luckyColor: "Green",
    mood: "Content",
    compatibility: "Scorpio"
  },
  // More signs would be added here
];

export default function DailyHoroscope() {
  const [activeSign, setActiveSign] = useState(zodiacSigns[0]);
  const [activeElement, setActiveElement] = useState("Fire");

  const elements = [
    { name: "Fire", signs: ["Aries", "Leo", "Sagittarius"] },
    { name: "Earth", signs: ["Taurus", "Virgo", "Capricorn"] },
    { name: "Air", signs: ["Gemini", "Libra", "Aquarius"] },
    { name: "Water", signs: ["Cancer", "Scorpio", "Pisces"] }
  ];

  return (
    <main className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Daily Horoscope</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Discover what the stars have in store for you today. Select your zodiac
          sign to read your personalized daily horoscope.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="col-span-1 p-6">
          <h2 className="text-2xl font-bold mb-2">Choose Your Sign</h2>
          <p className="text-muted-foreground mb-4">
            Select your zodiac sign to view your daily horoscope
          </p>

          <Tabs defaultValue="Fire" className="w-full">
            <TabsList className="grid grid-cols-4 mb-4">
              {elements.map((element) => (
                <TabsTrigger
                  key={element.name}
                  value={element.name}
                  onClick={() => setActiveElement(element.name)}
                >
                  {element.name}
                </TabsTrigger>
              ))}
            </TabsList>

            {elements.map((element) => (
              <TabsContent key={element.name} value={element.name} className="mt-0">
                <div className="grid grid-cols-3 gap-2">
                  {zodiacSigns
                    .filter((sign) => elements.find(e => e.name === element.name)?.signs.includes(sign.name))
                    .map((sign) => (
                      <div
                        key={sign.name}
                        className={`p-3 rounded text-center cursor-pointer transition-all duration-200 ${
                          activeSign.name === sign.name
                            ? "bg-primary text-white"
                            : "bg-muted/50 hover:bg-muted"
                        }`}
                        onClick={() => setActiveSign(sign)}
                      >
                        {sign.name}
                      </div>
                    ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </Card>

        <Card className="col-span-1 md:col-span-2 p-6">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h2 className="text-2xl font-bold">{activeSign.name}</h2>
              <p className="text-muted-foreground">{activeSign.dates}</p>
            </div>
            <Button variant="ghost" size="icon">
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>

          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-semibold mb-2">Today's Horoscope</h3>
              <p className="text-muted-foreground">{activeSign.horoscope.general}</p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 py-4">
              <div className="text-center">
                <p className="text-sm text-muted-foreground">Lucky Number</p>
                <p className="font-semibold text-lg">{activeSign.luckyNumber}</p>
              </div>
              <div className="text-center">
                <p className="text-sm text-muted-foreground">Lucky Color</p>
                <p className="font-semibold text-lg">{activeSign.luckyColor}</p>
              </div>
              <div className="text-center">
                <p className="text-sm text-muted-foreground">Mood</p>
                <p className="font-semibold text-lg">{activeSign.mood}</p>
              </div>
              <div className="text-center">
                <p className="text-sm text-muted-foreground">Compatibility</p>
                <p className="font-semibold text-lg">{activeSign.compatibility}</p>
              </div>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-2">Love & Relationships</h3>
              <p className="text-muted-foreground">{activeSign.horoscope.love}</p>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-2">Career & Money</h3>
              <p className="text-muted-foreground">{activeSign.horoscope.career}</p>
            </div>

            <div>
              <h3 className="text-xl font-semibold mb-2">Health & Wellness</h3>
              <p className="text-muted-foreground">{activeSign.horoscope.health}</p>
            </div>
          </div>
        </Card>
      </div>
    </main>
  );
}
