# AstroGuide
Astrology Website!
 This is a website which can help you to know everything about yourself through astrology knowledge.You can learn what your zodiac sign says about you. The effect of the 12 houses and the planets on you can also be known.A person's basic personality, outer personality and emotions is also told in brief.Moreover, you can also know about your love compatibility with other people based on the zodiac signs and also the darker and mysterious secrets about you can also be unveiled.
