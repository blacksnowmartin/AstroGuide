npx create-react-app Astropath

To run the project you hhave to run 

cd Astropath && npm start

# Astropath
Astropath is a web application that provides users with personalized astrological insights and daily horoscopes.
A zodiac sign selector for all 12 signs.
Daily horoscope display fetched from the free aztro API.
Zodiac sign descriptions displayed alongside the horoscope.
Dynamic background color and glowing animation that changes based on the selected zodiac sign, making the page visually lively and eventful.

Blacksnow Martin is the lead developer and designer of the Astropath application.