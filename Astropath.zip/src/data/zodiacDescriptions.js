const zodiacDescriptions = {
  aries: "Aries is the first sign of the zodiac, known for being courageous, energetic, and confident.",
  taurus: "Taurus is reliable, patient, and devoted. They enjoy the rewards of their hard work.",
  gemini: "Gemini is adaptable, outgoing, and intelligent. They love to communicate and learn new things.",
  cancer: "Cancer is intuitive, caring, and protective. They value family and close relationships.",
  leo: "Leo is charismatic, generous, and creative. They love to be in the spotlight.",
  virgo: "Virgo is analytical, practical, and diligent. They pay attention to detail and strive for perfection.",
  libra: "Libra is diplomatic, charming, and fair-minded. They seek balance and harmony.",
  scorpio: "Scorpio is passionate, resourceful, and determined. They have strong emotional depth.",
  sagittarius: "Sagittarius is adventurous, optimistic, and independent. They love freedom and exploration.",
  capricorn: "Capricorn is disciplined, responsible, and ambitious. They work hard to achieve their goals.",
  aquarius: "Aquarius is innovative, humanitarian, and intellectual. They think outside the box.",
  pisces: "Pisces is compassionate, artistic, and intuitive. They are deeply empathetic and imaginative."
};

export default zodiacDescriptions;
