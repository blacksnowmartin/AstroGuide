import React from 'react';

const zodiacSigns = [
  'aries', 'taurus', 'gemini', 'cancer', 'leo', 'virgo',
  'libra', 'scorpio', 'sagittarius', 'capricorn', 'aquarius', 'pisces'
];

function ZodiacSignSelector({ selectedSign, onSelectSign }) {
  return (
    <div className="zodiac-sign-selector">
      <h2>Select Your Zodiac Sign</h2>
      <div className="sign-buttons">
        {zodiacSigns.map(sign => (
          <button
            key={sign}
            className={sign === selectedSign ? 'selected' : ''}
            onClick={() => onSelectSign(sign)}
          >
            {sign.charAt(0).toUpperCase() + sign.slice(1)}
          </button>
        ))}
      </div>
    </div>
  );
}

export default ZodiacSignSelector;
