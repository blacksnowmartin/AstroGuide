import React, { useEffect, useState } from 'react';
import zodiacDescriptions from '../data/zodiacDescriptions';

function HoroscopeDisplay({ sign, horoscopeData, setHoroscopeData }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!sign) return;

    setLoading(true);
    setError(null);

    fetch(`https://aztro.sameerkumar.website/?sign=${sign}&day=today`, {
      method: 'POST'
    })
      .then(response => response.json())
      .then(data => {
        setHoroscopeData(data);
        setLoading(false);
      })
      .catch(err => {
        setError('Failed to fetch horoscope. Please try again later.');
        setLoading(false);
      });
  }, [sign, setHoroscopeData]);

  if (loading) {
    return <div>Loading horoscope...</div>;
  }

  if (error) {
    return <div>{error}</div>;
  }

  if (!horoscopeData) {
    return null;
  }

  return (
    <div className="horoscope-display">
      <h2>Daily Horoscope for {sign.charAt(0).toUpperCase() + sign.slice(1)}</h2>
      <p>{horoscopeData.description}</p>
      <ul>
        <li><strong>Lucky Number:</strong> {horoscopeData.lucky_number}</li>
        <li><strong>Lucky Color:</strong> {horoscopeData.color}</li>
        <li><strong>Mood:</strong> {horoscopeData.mood}</li>
        <li><strong>Compatibility:</strong> {horoscopeData.compatibility}</li>
      </ul>
      <div className="zodiac-description">
        <h3>About {sign.charAt(0).toUpperCase() + sign.slice(1)}</h3>
        <p>{zodiacDescriptions[sign]}</p>
      </div>
    </div>
  );
}

export default HoroscopeDisplay;
