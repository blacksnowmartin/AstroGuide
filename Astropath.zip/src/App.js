import React, { useState } from 'react';
import ZodiacSignSelector from './components/ZodiacSignSelector';
import HoroscopeDisplay from './components/HoroscopeDisplay';
import './App.css';

const zodiacColors = {
  aries: '#FF4500',
  taurus: '#228B22',
  gemini: '#FFD700',
  cancer: '#4682B4',
  leo: '#FF8C00',
  virgo: '#6B8E23',
  libra: '#DA70D6',
  scorpio: '#8B0000',
  sagittarius: '#FF6347',
  capricorn: '#2F4F4F',
  aquarius: '#00CED1',
  pisces: '#1E90FF'
};

function App() {
  const [selectedSign, setSelectedSign] = useState('aries');
  const [horoscopeData, setHoroscopeData] = useState(null);

  const backgroundColor = zodiacColors[selectedSign] || '#f5f7fa';

  return (
    <div className="App" style={{ backgroundColor, transition: 'background-color 1s ease' }}>
      <header className="App-header">
        <h1>Astropath - Daily Horoscope</h1>
      </header>
      <main>
        <ZodiacSignSelector selectedSign={selectedSign} onSelectSign={setSelectedSign} />
        <HoroscopeDisplay sign={selectedSign} horoscopeData={horoscopeData} setHoroscopeData={setHoroscopeData} />
      </main>
    </div>
  );
}

export default App;
